//
//  ViewController.m
//  CoreDataSample
//
//  Created by Prerna on 5/6/16.
//  Copyright © 2016 NarolaInfotech. All rights reserved.
//

#import "ViewController.h"
#import "WebServiceConnector.h"
#import "ReachabilityManager.h"
#import "Constants.h"
#import "FamousFoodWS.h"
#import "Restaurant.h"
#import "Books+CoreDataClass.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arrRestaurant = [NSMutableArray new];
    if([ReachabilityManager isReachable])
    {
        [[WebServiceConnector alloc]init:URLGetFamousFood
                          withParameters:nil
                              withObject:self
                            withSelector:@selector(handleWSResponse:)
                          forServiceType:@"GET"
                          showDisplayMsg:@"No message"];
    }
    else
    {
    }
    NSLog(@"Random: %@",[self getRandomRecord:@"Books"]);
}
- (void)handleWSResponse:(id)sender
{
    [SVProgressHUD dismiss];
    if ([sender responseCode] != 100)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:[sender responseError] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
    }
    else
    {
        NSLog(@"%@", [sender responseArray]);
        NSLog(@"%@", [sender responseDict]);
        //[self DisplayFromCoreDB];
        
        for (int i =0 ; i<[[sender responseArray] count]; i++)
        {
            FamousFoodWS *food = [[sender responseArray] objectAtIndex:i];
            NSLog(@"Title: %@",food.title);
            NSLog(@"Location: %@",food.location);
        }
        arrRestaurant = [sender responseArray];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnInsert:(id)sender
{
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    for(int i=0 ; i<[arrRestaurant count]; i++)
    {
        Restaurant *restaurant = [NSEntityDescription
                                  insertNewObjectForEntityForName:@"Restaurant"
                                  inManagedObjectContext:context];
        restaurant.title = ((FamousFoodWS *)[arrRestaurant objectAtIndex:i]).title;
        restaurant.location = ((FamousFoodWS *)[arrRestaurant objectAtIndex:i]).location;
        restaurant.fooddescription = ((FamousFoodWS *)[arrRestaurant objectAtIndex:i]).famousFoodDescription;
        NSError *error;
        if (![context save:&error])
        {
            NSLog(@"Whoops,couldn't save: %@", [error localizedDescription]);
        }
    }
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:@"Message"
                                          message:[NSString stringWithFormat:@"Total records after insert: %ld",
                                                   [self getRecordCount:@"Restaurant"]]
                                          preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction
                                   actionWithTitle:@"Cancel"
                                   style:UIAlertActionStyleCancel
                                   handler:^(UIAlertAction *action)
                                   {
                                       NSLog(@"Cancel action");
                                   }];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:@"OK"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   NSLog(@"OK action");
                               }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (IBAction)btnDelete:(id)sender
{
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    [fetchRequest setEntity:[NSEntityDescription entityForName:@"Restaurant" inManagedObjectContext:context]];
    [fetchRequest setPredicate:[NSPredicate predicateWithFormat:@"title CONTAINS %@", @"Sai"]];
    NSError* error = nil;
    NSArray* results = [context executeFetchRequest:fetchRequest error:&error];
    
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:@"Message"
                                          message:[NSString stringWithFormat:@"Total records found for search criteria : %ld do you wish to delete?",[results count]]
                                          preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:@"Yes"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   
                                   for (NSManagedObject *managedObject in results)
                                   {
                                       [context deleteObject:managedObject];
                                   }
                               }];
    UIAlertAction *cancelAction = [UIAlertAction
                                   actionWithTitle:@"No"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction *action)
                                   {
                                   }];
    [alertController addAction:okAction];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];
    if (![context save:&error])
    {
        NSLog(@"[ERROR] Error deleting - error:%@",  error);
    }
}

- (IBAction)btnDeleteAll:(id)sender
{
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    [fetchRequest setEntity:[NSEntityDescription entityForName:@"Books" inManagedObjectContext:context]];
    NSError* error = nil;
    NSArray* results = [context executeFetchRequest:fetchRequest error:&error];
    for (NSManagedObject *managedObject in results)
    {
        [context deleteObject:managedObject];
    }
    
    if (![context save:&error])
    {
        NSLog(@"[ERROR] Error deleting - error:%@",  error);
    }
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:@"Message"
                                          message:[NSString stringWithFormat:@"Total records after delete: %ld",[self getRecordCount:@"Restaurant"]]
                                          preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:@"OK"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {}];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
    
}

- (IBAction)btnSelect1:(id)sender
{
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:@"Message"
                                          message:[NSString stringWithFormat:@"Total records in table: %ld",[self getRecordCount:@"Books"]]
                                          preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:@"OK"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {}];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}
- (IBAction)btnLoadTable:(id)sender
{
    NSError* err = nil;
    NSString* dataPath = [[NSBundle mainBundle] pathForResource:@"book" ofType:@"json"];
    NSDictionary *dictbooks = [NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfFile:dataPath]
                                                              options:kNilOptions
                                                                error:&err];
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    for(int i=0 ; i<[[dictbooks objectForKey:@"books"] count]; i++)
    {
        Books *book = [NSEntityDescription
                       insertNewObjectForEntityForName:@"Books"
                       inManagedObjectContext:context];
        book.author = [[[dictbooks objectForKey:@"books"] objectAtIndex:i] objectForKey:@"author"];
        book.book_name = [[[dictbooks objectForKey:@"books"]objectAtIndex:i] objectForKey:@"book_title"];
        book.book_description = [[[dictbooks objectForKey:@"books"]objectAtIndex:i] objectForKey:@"book_description"];
        book.book_image=[[[dictbooks objectForKey:@"books"]objectAtIndex:i] objectForKey:@"book_image"];
        book.book_pdf=[[[dictbooks objectForKey:@"books"]objectAtIndex:i] objectForKey:@"pdf_file"];
        NSError *error;
        if (![context save:&error])
        {
            NSLog(@"Whoops,couldn't save: %@", [error localizedDescription]);
        }
    }
}

- (IBAction)btnUpdate:(id)sender
{
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"Restaurant" inManagedObjectContext:context]];
    
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:request error:&error];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"FoodName contains[c] %@", @"Bhel puri"];
    [request setPredicate:predicate];
    Restaurant *restaurant = [results objectAtIndex:0];
    [restaurant.title stringByReplacingOccurrencesOfString:@"Bhel puri" withString:@"BhelPuri"];
    if (![context save:&error])
    {
        NSLog(@"[ERROR] Error deleting - error:%@",  error);
    }
}

- (IBAction)btnSelect:(id)sender
{
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"Restaurant" inManagedObjectContext:context]];
    
    NSError *error = nil;
    NSArray *results = [context executeFetchRequest:request error:&error];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"FoodName contains[c] %@", @"BhelPuri"];
    [request setPredicate:predicate];
    Restaurant *restaurant = [results objectAtIndex:0];
    NSLog(@"%@",restaurant.title);
}

#pragma mark - Additional CoreData Methods
-(NSInteger)getRecordCount: (NSString *)tablename
{
    NSFetchRequest *fetchrequest = [[NSFetchRequest alloc] init];
    [fetchrequest setEntity:[NSEntityDescription entityForName:tablename
                                        inManagedObjectContext:[APP_DELEGATE managedObjectContext]]];
    NSError *error = nil;
    NSArray *arrData = [[APP_DELEGATE managedObjectContext] executeFetchRequest:fetchrequest error:&error];
    
    return [arrData count];
}
-(id)getRandomRecord: (NSString *)tablename
{
    NSFetchRequest *fetchrequest = [[NSFetchRequest alloc] init];
    [fetchrequest setEntity:[NSEntityDescription entityForName:tablename
                                        inManagedObjectContext:[APP_DELEGATE managedObjectContext]]];
    NSError *error = nil;

    NSUInteger myEntityCount = [[APP_DELEGATE managedObjectContext] countForFetchRequest:fetchrequest error:&error];
    
    NSUInteger offset = myEntityCount - (arc4random() % myEntityCount);
    [fetchrequest setFetchOffset:offset];
    [fetchrequest setFetchLimit:5];
    
    NSArray* arrBook = [[APP_DELEGATE managedObjectContext] executeFetchRequest:fetchrequest error:&error];
    for (int i=0;i <[arrBook count]; i++) {
        Books *book =[arrBook objectAtIndex:i];
        NSLog(@"Name:%@",book.book_name);
    }
    
    return nil;
}
@end
