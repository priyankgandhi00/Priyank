//
//  Contactinfo+CoreDataProperties.h
//  CoreDataSample
//
//  Created by Prerna on 5/6/16.
//  Copyright © 2016 NarolaInfotech. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Contactinfo.h"

NS_ASSUME_NONNULL_BEGIN

@interface Contactinfo (CoreDataProperties)

@property (nullable, nonatomic, retain) NSNumber *contactid;
@property (nullable, nonatomic, retain) NSString *contactname;
@property (nullable, nonatomic, retain) NSNumber *contactnumber;
@property (nullable, nonatomic, retain) NSString *restaurantname;

@end

NS_ASSUME_NONNULL_END
