//
//  Books+CoreDataClass.h
//  CoreDataSampleWithoutFramework
//
//  Created by Prerna on 3/6/17.
//  Copyright © 2017 NarolaInfotech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Books : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Books+CoreDataProperties.h"
