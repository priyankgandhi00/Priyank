//
//  Restaurant.h
//  CoreDataSample
//
//  Created by Prerna on 5/6/16.
//  Copyright © 2016 NarolaInfotech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Images;

NS_ASSUME_NONNULL_BEGIN

@interface Restaurant : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "Restaurant+CoreDataProperties.h"
