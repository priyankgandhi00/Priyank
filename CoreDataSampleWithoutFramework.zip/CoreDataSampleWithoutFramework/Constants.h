//
//  constants.h
//  acloud
//
//  Created by iMac on 15/06/14.
//  Copyright (c) 2014 iMac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//#import "CoreDataHelper.h"

#import "AppDelegate.h"
#import "SVProgressHUD.h"
#import "Function.h"


@interface Constants : NSObject
{
    
}

/* ============================================================================ */
#pragma mark - Web Service Requests
#define Server_URL    ""
#define URLGetFamousFood [NSString stringWithFormat:@"http://192.168.1.63/foodcityWS1316/getAllFamousFood.php"]

#define URLGetSetsWithQuestions @"http://54.148.253.15/VillageQuizApp/WSNew/VillageQuizService.php?Service=FetchSetsWithQuestions"

#define URLAddProfile @"http://54.148.253.15/WS_Demo/DemoService.php?Service=AddProfile"

#define URLRegister @"http://54.148.253.15/VillageQuizApp/WSNew/VillageQuizService.php?Service=Register"

/* ============================================================================ */
#pragma mark - Class,Json Key and Message

#define WebserviceDialogMsg @"Processing"

#define GetFamousFoodClass @"FamousFoodWS"
#define GetFamousFoodEntity @"FamousFood"
#define GetFamousFoodKey @"FamousFood"
#define GetFamousFoodMsg [NSString stringWithFormat:@"%@ FamousFood",WebserviceDialogMsg]

#define GetSetsWithQuestionsClass @"QuestionSets"
#define GetSetsWithQuestionsEntity @""
#define GetSetsWithQuestionsKey @"data"
#define GetSetsWithQuestionsMsg [NSString stringWithFormat:@"%@ Sets",WebserviceDialogMsg]

#define AddProfileClass @"ProfileDetails"
#define AddProfileEntity @""
#define AddProfileKey @"profile_details"
#define AddProfileMsg [NSString stringWithFormat:@"%@ Sets",WebserviceDialogMsg]



#define WSRegisterKeyMessage @"Message"
#define WSRegisterKeyStatus @"Status"


/* ============================================================================ */

//#import "UIViewController+Helper.h"

/* ============================================================================ */
#pragma mark - General Constants
#define APP_DELEGATE  (AppDelegate*)[[UIApplication sharedApplication] delegate]

#define isService( key ) \
[requestURL isEqualToString: key ]

#define ARRAY(key, ...) [NSMutableArray arrayWithObjects:key,##__VA_ARGS__]

#define ShowNetworkIndicator(XXX) [UIApplication sharedApplication].networkActivityIndicatorVisible = XXX;

#define CurrentTimeStamp [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000]

@end
