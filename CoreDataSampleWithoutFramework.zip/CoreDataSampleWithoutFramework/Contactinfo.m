//
//  Contactinfo.m
//  CoreDataSample
//
//  Created by Prerna on 5/6/16.
//  Copyright © 2016 NarolaInfotech. All rights reserved.
//

#import "Contactinfo.h"

@implementation Contactinfo

// Insert code here to add functionality to your managed object subclass

@end
