//
//  Books+CoreDataProperties.h
//  CoreDataSampleWithoutFramework
//
//  Created by Prerna on 3/6/17.
//  Copyright © 2017 NarolaInfotech. All rights reserved.
//

#import "Books+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Books (CoreDataProperties)

+ (NSFetchRequest<Books *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *book_pdf;
@property (nullable, nonatomic, copy) NSString *book_image;
@property (nullable, nonatomic, copy) NSString *book_description;
@property (nullable, nonatomic, copy) NSString *book_name;
@property (nullable, nonatomic, copy) NSString *author;

@end

NS_ASSUME_NONNULL_END
