#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface FamousFoodWS : NSObject


@property (nonatomic,strong) NSString *call;
@property (nonatomic,strong) NSString *famousFoodDescription;
@property (nonatomic,strong) NSString *timing;
@property (nonatomic,strong) NSString *location;
@property (nonatomic,strong) NSString *ratings;
@property (nonatomic,strong) NSString *foodName;
@property (nonatomic,strong) NSArray  *images;
@property (nonatomic,strong) NSString *sitting;
@property (nonatomic,strong) NSString *numberOfReviews;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *partyOrder;
@property (nonatomic,strong) NSString *landmark;
@property (nonatomic,strong) NSString *areaId;
@property (nonatomic,strong) NSString *foodID;
@property (nonatomic,strong) NSString *vegNonVeg;

#pragma mark - webservice helper
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;
@end
