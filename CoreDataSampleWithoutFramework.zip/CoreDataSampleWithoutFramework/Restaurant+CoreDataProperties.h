//
//  Restaurant+CoreDataProperties.h
//  CoreDataSample
//
//  Created by Prerna on 5/6/16.
//  Copyright © 2016 NarolaInfotech. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Restaurant.h"

NS_ASSUME_NONNULL_BEGIN

@interface Restaurant (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *areaid;
@property (nullable, nonatomic, retain) NSNumber *call;
@property (nullable, nonatomic, retain) NSString *fooddescription;
@property (nullable, nonatomic, retain) NSNumber *foodid;
@property (nullable, nonatomic, retain) NSString *landmark;
@property (nullable, nonatomic, retain) NSString *location;
@property (nullable, nonatomic, retain) NSString *numberofreviews;
@property (nullable, nonatomic, retain) NSString *partyorder;
@property (nullable, nonatomic, retain) NSString *ratings;
@property (nullable, nonatomic, retain) NSString *sitting;
@property (nullable, nonatomic, retain) NSString *timing;
@property (nullable, nonatomic, retain) NSString *title;
@property (nullable, nonatomic, retain) Images *imageinfo;

@end

NS_ASSUME_NONNULL_END
