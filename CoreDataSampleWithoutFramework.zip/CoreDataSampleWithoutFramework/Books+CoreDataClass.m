//
//  Books+CoreDataClass.m
//  CoreDataSampleWithoutFramework
//
//  Created by Prerna on 3/6/17.
//  Copyright © 2017 NarolaInfotech. All rights reserved.
//

#import "Books+CoreDataClass.h"

@implementation Books

@end
