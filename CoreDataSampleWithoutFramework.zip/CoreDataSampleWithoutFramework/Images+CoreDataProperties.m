//
//  Images+CoreDataProperties.m
//  CoreDataSample
//
//  Created by Prerna on 5/6/16.
//  Copyright © 2016 NarolaInfotech. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Images+CoreDataProperties.h"

@implementation Images (CoreDataProperties)

@dynamic imageid;
@dynamic imagename;
@dynamic restrodetail;

@end
