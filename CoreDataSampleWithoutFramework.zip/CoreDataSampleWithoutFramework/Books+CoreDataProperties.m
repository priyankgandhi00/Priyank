//
//  Books+CoreDataProperties.m
//  CoreDataSampleWithoutFramework
//
//  Created by Prerna on 3/6/17.
//  Copyright © 2017 NarolaInfotech. All rights reserved.
//

#import "Books+CoreDataProperties.h"

@implementation Books (CoreDataProperties)

+ (NSFetchRequest<Books *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Books"];
}

@dynamic book_pdf;
@dynamic book_image;
@dynamic book_description;
@dynamic book_name;
@dynamic author;

@end
