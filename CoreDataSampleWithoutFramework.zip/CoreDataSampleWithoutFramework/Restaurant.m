//
//  Restaurant.m
//  CoreDataSample
//
//  Created by Prerna on 5/6/16.
//  Copyright © 2016 NarolaInfotech. All rights reserved.
//

#import "Restaurant.h"
#import "Images.h"

@implementation Restaurant

// Insert code here to add functionality to your managed object subclass

@end
