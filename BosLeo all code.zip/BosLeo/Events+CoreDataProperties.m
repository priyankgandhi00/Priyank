//
//  Events+CoreDataProperties.m
//  BosLeo
//
//  Created by Priyank Gandhi on 12/03/17.
//  Copyright © 2017 Priyank Gandhi. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Events+CoreDataProperties.h"

@implementation Events (CoreDataProperties)

+ (NSFetchRequest<Events *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Events"];
}

@dynamic eventId;
@dynamic modifiedDate;
@dynamic title;
@dynamic distance;

@end
