//
//  ViewController.m
//  BosLeo
//
//  Created by  Gandhi on 11/03/17.
//  Copyright © 2017  Gandhi. All rights reserved.
//

#import "ViewController.h"
#import "EventsCell.h"
#import "WebServiceConnector.h"
#import "events.h"
#import "Events+CoreDataProperties.h"

@interface ViewController ()
{
    NSMutableArray *arrData;
    bool isSearch;
    NSMutableArray	*filteredListContent;
    NSMutableDictionary *dictContact;
}
@end

@implementation ViewController
@synthesize searchBar;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    isSearch = NO;
    
    _tblData.estimatedRowHeight = 44.0;
    _tblData.rowHeight = UITableViewAutomaticDimension;
    
    filteredListContent = [[NSMutableArray alloc]init];
    dictContact = [[NSMutableDictionary alloc]init];
    arrData = [[NSMutableArray alloc]init];
    
    
    NSLog(@"Documents Directory: %@", [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject]);
    
//    NSMutableDictionary     *userDic = [[NSMutableDictionary alloc]init];
//    [userDic setValue:@"37.173984" forKey:@"latitude"];
//    [userDic setValue:@"-3.603934" forKey:@"longitude"];
//    [[WebServiceConnector alloc]init:URLFBUserCheck withParameters:userDic withObject:self withSelector:@selector(getResponse:) forServiceType:@"JSON" showDisplayMsg:UserMsg];

    [self getRandomRecord:@"Events"];
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

-(IBAction) getResponse:(id)sender
{
    
    if ([sender responseCode] == 100) {
        if([[[sender responseDict]valueForKey:@"status"] integerValue] ==0)
        {
            
        }
        else{
            arrData = [NSMutableArray arrayWithArray:[sender responseArray]];
            [_tblData reloadData];
        }
    }
    else{
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Title"
                                     message:@"Message"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        
        UIAlertAction* noButton = [UIAlertAction
                                   actionWithTitle:@"ok"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action) {
                                       //Handle no, thanks button
                                   }];
        
        [alert addAction:noButton];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
}

-(id)getRandomRecord: (NSString *)tablename
{
    NSFetchRequest *fetchrequest = [[NSFetchRequest alloc] init];
    [fetchrequest setEntity:[NSEntityDescription entityForName:tablename
                                        inManagedObjectContext:[APP_DELEGATE managedObjectContext]]];
    NSError *error = nil;

    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"title"
                                                                   ascending:YES];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    [fetchrequest setSortDescriptors:sortDescriptors];

    NSArray* arrBook = [[APP_DELEGATE managedObjectContext] executeFetchRequest:fetchrequest error:&error];
    
    NSString *strChar;
    NSMutableArray *arrTemp = [[NSMutableArray alloc]init];
    strChar = [((events *)[arrBook objectAtIndex:0]).title substringToIndex:1];
    
    for (int i=0;i <[arrBook count]; i++) {
        Events *book =[arrBook objectAtIndex:i];
        [arrData addObject:book];
        NSLog(@"Name:%@",book.title);
        
        if([strChar isEqualToString:[book.title substringToIndex:1]])
        {
            [arrTemp addObject:book];
        }
        else
        {
            [dictContact setObject:[NSMutableArray arrayWithArray:arrTemp] forKey:strChar];
            [arrTemp removeAllObjects];
            strChar = [book.title substringToIndex:1];
        }
    }
    [arrTemp addObject:[arrBook objectAtIndex:[arrData count]-1]];
    [dictContact setObject:[NSMutableArray arrayWithArray:arrTemp] forKey:strChar];
    NSLog(@"%@",dictContact);
    [_tblData reloadData];
    return nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Table view delegate methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [[dictContact.allKeys
             sortedArrayUsingSelector:@selector(compare:)] count];
}

//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
//{
//    if (goingStatus != nil) {
//        return 0;
//    }
//    else{
//        return 25;
//    }
//    
//    /*if (isUserOfTheMonth) {
//     if (arrFeeds.count == 0) {
//     return 15;
//     }
//     
//     return 8.0;
//     }
//     else{
//     return 0;
//     }*/
//    
//}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [[dictContact.allKeys
             sortedArrayUsingSelector:@selector(compare:)] objectAtIndex:section];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (isSearch == YES)
    {
        return [filteredListContent count];
    }
    else
        return [[dictContact valueForKey:[[dictContact.allKeys
                                           sortedArrayUsingSelector:@selector(compare:)] objectAtIndex:section]] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"EventsCell";
    EventsCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    if (isSearch == YES)
    {
        cell.lblTitlw.text = ((events *)[filteredListContent objectAtIndex:indexPath.row]).title;
    }
    else
    {
        //cell.lblTitlw.text = ((events *)[arrData objectAtIndex:indexPath.row]).title;
        NSLog(@"Size : %@",[[dictContact allKeys] objectAtIndex:indexPath.section]);
        cell.lblTitlw.text =  ((Events *)[[dictContact valueForKey:[[dictContact.allKeys
                                                                     sortedArrayUsingSelector:@selector(compare:)] objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row]).title;
    }
    
    
    
    
    //cell.lblTitlw.preferredMaxLayoutWidth = CGRectGetWidth(tableView.bounds);
    //[cell.lblTitlw sizeToFit];
    
    return cell;
}
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    return [dictContact.allKeys
             sortedArrayUsingSelector:@selector(compare:)];
}
- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
    
    return index;
}
#pragma mark -Search
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar1
{
    //isSearch = YES;
    // only show the status bar's cancel button while in edit mode
    searchBar.showsCancelButton = YES;
    searchBar.autocorrectionType = UITextAutocorrectionTypeNo;
//    if (searchBar.text.length==0) {
//        vwBlack.hidden = NO;
//    }
    
    // flush the previous search content
    //[task_valarr removeAllObjects];
}
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar1
{
    searchBar.showsCancelButton = NO;
    //vwBlack.hidden = YES;
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    [filteredListContent removeAllObjects];
    if([searchText isEqualToString:@""]||searchText==nil){
        [filteredListContent addObjectsFromArray:arrData];
        [_tblData reloadData];
        //vwBlack.hidden = NO;
        return;
    }
    isSearch = YES;
    
    NSPredicate *filterPredicate = [NSPredicate predicateWithFormat:@"title contains[cd] %@", searchText];
    filteredListContent = [NSMutableArray arrayWithArray:[[NSArray arrayWithArray:arrData] filteredArrayUsingPredicate:filterPredicate]];
    
    [_tblData reloadData];
}
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar1
{
    // if a valid search was entered but the user wanted to cancel, bring back the main list content
    //[task_valarr addObjectsFromArray:taskvaluelist_arr];
    [filteredListContent removeAllObjects];
    [filteredListContent addObjectsFromArray:arrData];
    [searchBar resignFirstResponder];
    searchBar.text = @"";
    isSearch = NO;
    [_tblData reloadData];
    
}

// called when Search (in our case "Done") button pressed
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar1
{
    [searchBar resignFirstResponder];
    
}
- (IBAction)btnDelete:(id)sender
{
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    [fetchRequest setEntity:[NSEntityDescription entityForName:@"Events" inManagedObjectContext:context]];
    [fetchRequest setPredicate:[NSPredicate predicateWithFormat:@"eventId == %@", @"125"]];
    NSError* error = nil;
    NSArray* results = [context executeFetchRequest:fetchRequest error:&error];
    
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:@"Message"
                                          message:[NSString stringWithFormat:@"Total records found for search criteria : %ld do you wish to delete?",[results count]]
                                          preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:@"Yes"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   
                                   for (NSManagedObject *managedObject in results)
                                   {
                                       [context deleteObject:managedObject];
                                   }
                               }];
    UIAlertAction *cancelAction = [UIAlertAction
                                   actionWithTitle:@"No"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction *action)
                                   {
                                   }];
    [alertController addAction:okAction];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];
    if (![context save:&error])
    {
        NSLog(@"[ERROR] Error deleting - error:%@",  error);
    }
}


@end
