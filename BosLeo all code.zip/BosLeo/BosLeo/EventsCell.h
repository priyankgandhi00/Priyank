//
//  EventsCell.h
//  BosLeo
//
//  Created by Priyank Gandhi on 12/03/17.
//  Copyright © 2017 Priyank Gandhi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitlw;

@end
