//
//  ViewController.h
//  BosLeo
//
//  Created by  Gandhi on 11/03/17.
//  Copyright © 2017  Gandhi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tblData;

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;

@end

