//
//  EventsCell.m
//  BosLeo
//
//  Created by Priyank Gandhi on 12/03/17.
//  Copyright © 2017 Priyank Gandhi. All rights reserved.
//

#import "EventsCell.h"

@implementation EventsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
