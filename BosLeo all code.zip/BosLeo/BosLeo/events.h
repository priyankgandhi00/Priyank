//
//  events.h
//
//  Created by Priyank Gandhi on 12/03/17
//  Copyright (c) 2017 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface events : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *modifiedDate;
@property (nonatomic, strong) NSString *internalBaseClassDescription;
@property (nonatomic, strong) NSString *internalBaseClassIdentifier;
@property (nonatomic, strong) NSString *latitude;
@property (nonatomic, strong) NSString *categoryId;
@property (nonatomic, strong) NSString *createdDate;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *longitude;
@property (nonatomic, strong) NSString *address;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *catName;
@property (nonatomic, strong) NSString *phoneNo;
@property (nonatomic, strong) NSString *distance;
@property (nonatomic, strong) NSString *website;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
