//
//  events.m
//
//  Created by Priyank Gandhi on 12/03/17
//  Copyright (c) 2017 __MyCompanyName__. All rights reserved.
//

#import "events.h"


NSString *const keventsModifiedDate = @"ModifiedDate";
NSString *const keventsDescription = @"Description";
NSString *const keventsId = @"Id";
NSString *const keventsLatitude = @"Latitude";
NSString *const keventsCategoryId = @"CategoryId";
NSString *const keventsCreatedDate = @"CreatedDate";
NSString *const keventsImage = @"image";
NSString *const keventsLongitude = @"Longitude";
NSString *const keventsAddress = @"Address";
NSString *const keventsTitle = @"Title";
NSString *const keventsCatName = @"catName";
NSString *const keventsPhoneNo = @"PhoneNo";
NSString *const keventsDistance = @"distance";
NSString *const keventsWebsite = @"website";


@interface events ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation events

@synthesize modifiedDate = _modifiedDate;
@synthesize internalBaseClassDescription = _internalBaseClassDescription;
@synthesize internalBaseClassIdentifier = _internalBaseClassIdentifier;
@synthesize latitude = _latitude;
@synthesize categoryId = _categoryId;
@synthesize createdDate = _createdDate;
@synthesize image = _image;
@synthesize longitude = _longitude;
@synthesize address = _address;
@synthesize title = _title;
@synthesize catName = _catName;
@synthesize phoneNo = _phoneNo;
@synthesize distance = _distance;
@synthesize website = _website;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.modifiedDate = [self objectOrNilForKey:keventsModifiedDate fromDictionary:dict];
            self.internalBaseClassDescription = [self objectOrNilForKey:keventsDescription fromDictionary:dict];
            self.internalBaseClassIdentifier = [self objectOrNilForKey:keventsId fromDictionary:dict];
            self.latitude = [self objectOrNilForKey:keventsLatitude fromDictionary:dict];
            self.categoryId = [self objectOrNilForKey:keventsCategoryId fromDictionary:dict];
            self.createdDate = [self objectOrNilForKey:keventsCreatedDate fromDictionary:dict];
            self.image = [self objectOrNilForKey:keventsImage fromDictionary:dict];
            self.longitude = [self objectOrNilForKey:keventsLongitude fromDictionary:dict];
            self.address = [self objectOrNilForKey:keventsAddress fromDictionary:dict];
            self.title = [self objectOrNilForKey:keventsTitle fromDictionary:dict];
            self.catName = [self objectOrNilForKey:keventsCatName fromDictionary:dict];
            self.phoneNo = [self objectOrNilForKey:keventsPhoneNo fromDictionary:dict];
            self.distance = [self objectOrNilForKey:keventsDistance fromDictionary:dict];
            self.website = [self objectOrNilForKey:keventsWebsite fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.modifiedDate forKey:keventsModifiedDate];
    [mutableDict setValue:self.internalBaseClassDescription forKey:keventsDescription];
    [mutableDict setValue:self.internalBaseClassIdentifier forKey:keventsId];
    [mutableDict setValue:self.latitude forKey:keventsLatitude];
    [mutableDict setValue:self.categoryId forKey:keventsCategoryId];
    [mutableDict setValue:self.createdDate forKey:keventsCreatedDate];
    [mutableDict setValue:self.image forKey:keventsImage];
    [mutableDict setValue:self.longitude forKey:keventsLongitude];
    [mutableDict setValue:self.address forKey:keventsAddress];
    [mutableDict setValue:self.title forKey:keventsTitle];
    [mutableDict setValue:self.catName forKey:keventsCatName];
    [mutableDict setValue:self.phoneNo forKey:keventsPhoneNo];
    [mutableDict setValue:self.distance forKey:keventsDistance];
    [mutableDict setValue:self.website forKey:keventsWebsite];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.modifiedDate = [aDecoder decodeObjectForKey:keventsModifiedDate];
    self.internalBaseClassDescription = [aDecoder decodeObjectForKey:keventsDescription];
    self.internalBaseClassIdentifier = [aDecoder decodeObjectForKey:keventsId];
    self.latitude = [aDecoder decodeObjectForKey:keventsLatitude];
    self.categoryId = [aDecoder decodeObjectForKey:keventsCategoryId];
    self.createdDate = [aDecoder decodeObjectForKey:keventsCreatedDate];
    self.image = [aDecoder decodeObjectForKey:keventsImage];
    self.longitude = [aDecoder decodeObjectForKey:keventsLongitude];
    self.address = [aDecoder decodeObjectForKey:keventsAddress];
    self.title = [aDecoder decodeObjectForKey:keventsTitle];
    self.catName = [aDecoder decodeObjectForKey:keventsCatName];
    self.phoneNo = [aDecoder decodeObjectForKey:keventsPhoneNo];
    self.distance = [aDecoder decodeObjectForKey:keventsDistance];
    self.website = [aDecoder decodeObjectForKey:keventsWebsite];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_modifiedDate forKey:keventsModifiedDate];
    [aCoder encodeObject:_internalBaseClassDescription forKey:keventsDescription];
    [aCoder encodeObject:_internalBaseClassIdentifier forKey:keventsId];
    [aCoder encodeObject:_latitude forKey:keventsLatitude];
    [aCoder encodeObject:_categoryId forKey:keventsCategoryId];
    [aCoder encodeObject:_createdDate forKey:keventsCreatedDate];
    [aCoder encodeObject:_image forKey:keventsImage];
    [aCoder encodeObject:_longitude forKey:keventsLongitude];
    [aCoder encodeObject:_address forKey:keventsAddress];
    [aCoder encodeObject:_title forKey:keventsTitle];
    [aCoder encodeObject:_catName forKey:keventsCatName];
    [aCoder encodeObject:_phoneNo forKey:keventsPhoneNo];
    [aCoder encodeObject:_distance forKey:keventsDistance];
    [aCoder encodeObject:_website forKey:keventsWebsite];
}

- (id)copyWithZone:(NSZone *)zone
{
    events *copy = [[events alloc] init];
    
    if (copy) {

        copy.modifiedDate = [self.modifiedDate copyWithZone:zone];
        copy.internalBaseClassDescription = [self.internalBaseClassDescription copyWithZone:zone];
        copy.internalBaseClassIdentifier = [self.internalBaseClassIdentifier copyWithZone:zone];
        copy.latitude = [self.latitude copyWithZone:zone];
        copy.categoryId = [self.categoryId copyWithZone:zone];
        copy.createdDate = [self.createdDate copyWithZone:zone];
        copy.image = [self.image copyWithZone:zone];
        copy.longitude = [self.longitude copyWithZone:zone];
        copy.address = [self.address copyWithZone:zone];
        copy.title = [self.title copyWithZone:zone];
        copy.catName = [self.catName copyWithZone:zone];
        copy.phoneNo = [self.phoneNo copyWithZone:zone];
        copy.distance = [self.distance copyWithZone:zone];
        copy.website = [self.website copyWithZone:zone];
    }
    
    return copy;
}


@end
