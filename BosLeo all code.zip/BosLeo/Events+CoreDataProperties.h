//
//  Events+CoreDataProperties.h
//  BosLeo
//
//  Created by Priyank Gandhi on 12/03/17.
//  Copyright © 2017 Priyank Gandhi. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "Events+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Events (CoreDataProperties)

+ (NSFetchRequest<Events *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *eventId;
@property (nullable, nonatomic, copy) NSString *modifiedDate;
@property (nullable, nonatomic, copy) NSString *title;
@property (nullable, nonatomic, copy) NSString *distance;

@end

NS_ASSUME_NONNULL_END
