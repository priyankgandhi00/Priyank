//
//  CoreDataWrapper.m
//  NIPLiOSFramework
//
//  Created by Prerna on 5/21/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import "CoreDataAdaptor.h"
#import "Restaurant.h"
#import "CoreDataHelper.h"

NSFetchedResultsController *fetchedResultController;

@implementation CoreDataAdaptor

#pragma mark - Helper Methods

+ (void)SaveDataInCoreDB:(NSDictionary *)dict forEntity:(NSString *)entityname
{
    //[[[FamousFood create] insert:dict] save];
    [[[NSClassFromString(entityname) create] insert:dict]save];
}

+(void)deleteDataInCoreDB:(NSString *)entityname withCondition:(NSString *)condition
{
    [Restaurant clear:[NSPredicate predicateWithFormat:condition]];
}
+(void)deleteAllDataInCoreDB:(NSString *)entityname
{
    [Restaurant clear:nil];
}

+ (NSArray *) fetchRestaurantWhere:(NSString *)condition
{
    NSArray *food = [[Restaurant query]where:condition].all;
    return food;
}

+ (NSArray *) fetchAllRestaurant
{
    NSArray *food = [Restaurant query].all;
    return food;
}

+ (void)updateRecords:(NSString *) condition
{
    //NSPredicate *condition1 = [NSPredicate predicateWithFormat:@"fooddescription contains[c] 'Bhel puri'"];
    NSArray *food = [[Restaurant query]where:condition].all;
    for(int i = 0; i< [food count];i++)
    {
        Restaurant * restaurant = [food objectAtIndex:i];
        [restaurant.title stringByReplacingOccurrencesOfString:@"Bhel puri" withString:@"BhelPuri"];
        restaurant.landmark = @"Near Iscon mall";
        [CoreDataHelper save];
    }
}

-(NSInteger)getRecordCount: (NSString *)entityname
{
    NSArray *arrRecords = [Restaurant query].all;
    return [arrRecords count];
}

/*********** Reference methods   *************/
+ (void)SaveRestaurantInCoreDB:(NSDictionary *)dict
{
    //
    //    [[[FamousFood create]
    //        insert:@{@"call":[NSNumber numberWithInteger:8128998654],
    //                 @"foodId":[NSNumber numberWithInteger:10],
    //                 @"foodname":@"Pavbhaji",
    //                 @"images":@"",
    //                 @"landmark":@"Temple",
    //                 @"location":@"Adajan",
    //                 @"ratings":[NSNumber numberWithInteger:5],
    //                 @"title":@"Mahesh Pavbhaji"}]
    //        save];
    //
    //    [[[FamousFood create] insert:dict]save];
    
}
+(NSArray *)getAllRestaurantFromCoreDB
{
    //    [FamousFood create];
    //    fetchedResultController = [[[[FamousFood query]order:@""]sectionNameKeyPath:@""]fetchedResultsController];
    //    NSLog(@"%@",fetchedResultController.fetchedObjects);
    return fetchedResultController.fetchedObjects;
}
+ (void)MapNSObjectToNSManagedObject:(NSString *)objClass forEntityName:(NSManagedObject *)entityname withDataSource:(NSMutableArray *)array
{
    //    if([array count] >0)
    //    {
    //
    //    }
    //    else
    //    {
    //        unsigned count;
    //        objc_property_t *properties = class_copyPropertyList([objClass class], &count);
    //        NSMutableDictionary *attributes = (NSMutableDictionary *)[[entityname entity] attributesByName];
    //        NSMutableDictionary *elements = [NSMutableDictionary dictionary];
    //        [elements setObject:[NSValue valueWithPointer:&RestaurantAttributes]
    //                       forKey:@"Keys"];
    //
    //        for (int i = 0; i < count; i++)
    //        {
    //            NSString *objectkey = [NSString stringWithUTF8String:property_getName(properties[i])];
    //            NSString *objectValue = [NSString stringWithUTF8String:property_copyAttributeValue(*properties, property_getName(properties[i]))];
    //            for (objectkey in [attributes allKeys])
    //            {
    //                //property_getName(properties[i]) = [attributes objectForKey:<#(nonnull id)#>]
    //                [attributes setValue:objectValue forKey:objectkey];
    //                NSLog(@"%@",attributes);
    //            }
    //        }
    //    }
}
+(NSInteger)getRecordCount: (NSString *)entityname
{
    return 0;
}

@end
