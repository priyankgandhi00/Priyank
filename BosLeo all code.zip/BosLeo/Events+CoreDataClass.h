//
//  Events+CoreDataClass.h
//  BosLeo
//
//  Created by Priyank Gandhi on 12/03/17.
//  Copyright © 2017 Priyank Gandhi. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Events : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Events+CoreDataProperties.h"
