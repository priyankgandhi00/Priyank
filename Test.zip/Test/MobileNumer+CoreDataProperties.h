//
//  MobileNumer+CoreDataProperties.h
//  Test
//
//  Created by Priyank Gandhi on 11/03/17.
//  Copyright © 2017 C211. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "MobileNumer+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface MobileNumer (CoreDataProperties)

+ (NSFetchRequest<MobileNumer *> *)fetchRequest;

@property (nonatomic) int64_t mobile_number;
@property (nullable, nonatomic, copy) NSDate *mobile_date;
@property (nullable, nonatomic, retain) Person *contact_relationship;

@end

NS_ASSUME_NONNULL_END
