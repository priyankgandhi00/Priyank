//
//  Person+CoreDataProperties.h
//  Test
//
//  Created by C211 on 11/03/17.
//  Copyright © 2017 C211. All rights reserved.
//

#import "Person+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Person (CoreDataProperties)

+ (NSFetchRequest<Person *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *person_name;
@property (nullable, nonatomic, retain) NSSet<MobileNumer *> *mobile_relationship;

@end

@interface Person (CoreDataGeneratedAccessors)

- (void)addMobile_relationshipObject:(MobileNumer *)value;
- (void)removeMobile_relationshipObject:(MobileNumer *)value;
- (void)addMobile_relationship:(NSSet<MobileNumer *> *)values;
- (void)removeMobile_relationship:(NSSet<MobileNumer *> *)values;

@end

NS_ASSUME_NONNULL_END
