//
//  ViewController.m
//  Test
//
//  Created by C211 on 11/03/17.
//  Copyright © 2017 C211. All rights reserved.
//

#import "ViewController.h"
#import "Person+CoreDataClass.h"
#import "MobileNumer+CoreDataClass.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"Documents Directory: %@", [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject]);
    
    NSManagedObjectContext *context = [APP_DELEGATE managedObjectContext];
    
        Person *restaurant = [NSEntityDescription
                                  insertNewObjectForEntityForName:@"Person"
                                  inManagedObjectContext:context];
        restaurant.person_name = @"Priyank1";
        
        
        MobileNumer *restaurant1 = [NSEntityDescription
                              insertNewObjectForEntityForName:@"MobileNumer"
                              inManagedObjectContext:context];
        
        restaurant1.mobile_number = [NSNumber numberWithInt:12345].integerValue;
        restaurant1.mobile_date = [NSDate date];
    
        MobileNumer *restaurant2 = [NSEntityDescription
                                    insertNewObjectForEntityForName:@"MobileNumer"
                                    inManagedObjectContext:context];
        
        restaurant2.mobile_number = 9879;

        
        restaurant.mobile_relationship = [NSSet setWithObjects:restaurant1,restaurant2, nil];;
        
        NSError *error;
        if (![context save:&error])
        {
            NSLog(@"Whoops,couldn't save: %@", [error localizedDescription]);
        }
    

    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
