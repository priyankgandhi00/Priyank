//
//  MobileNumer+CoreDataProperties.m
//  Test
//
//  Created by Priyank Gandhi on 11/03/17.
//  Copyright © 2017 C211. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "MobileNumer+CoreDataProperties.h"

@implementation MobileNumer (CoreDataProperties)

+ (NSFetchRequest<MobileNumer *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"MobileNumer"];
}

@dynamic mobile_number;
@dynamic mobile_date;
@dynamic contact_relationship;

@end
