//
//  MobileNumer+CoreDataClass.h
//  Test
//
//  Created by Priyank Gandhi on 11/03/17.
//  Copyright © 2017 C211. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Person;

NS_ASSUME_NONNULL_BEGIN

@interface MobileNumer : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "MobileNumer+CoreDataProperties.h"
