//
//  SecondViewController.h
//  DownloadDataDemo
//
//  Created by Prerna on 3/20/17.
//  Copyright © 2017 Narola Infotech. All rights reserved.
//

#import "ViewController.h"

@interface SecondViewController : ViewController

@end
