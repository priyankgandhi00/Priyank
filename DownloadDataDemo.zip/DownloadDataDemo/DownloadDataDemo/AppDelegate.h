//
//  AppDelegate.h
//  DownloadDataDemo
//
//  Created by Prerna on 3/14/17.
//  Copyright © 2017 Narola Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, copy) void(^backgroundTransferCompletionHandler)();

@end

