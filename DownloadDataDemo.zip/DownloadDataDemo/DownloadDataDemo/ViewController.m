//
//  ViewController.m
//  DownloadDataDemo
//
//  Created by Prerna on 3/14/17.
//  Copyright © 2017 Narola Infotech. All rights reserved.
//

#import "ViewController.h"
#import "DownloadManager.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


- (IBAction)btnStart:(id)sender
{
    NSString *url= @"http://54.203.15.120/ws/RTFTexts.zip";
    DownloadManager *download = [[DownloadManager alloc] initDownloadTask:url withZip:YES withDelegate:self];
    download.downloadDelegate = self;
    [_progressView setProgress:0 animated:YES];
}

- (IBAction)btnStop:(id)sender
{
}

#pragma mark - Download Manager delegate Methods
-(void)getDownloadStatistics:(double)totalBytes
            withBytesWritten:(double)bytesWritten
            withBytesToWrite:(double)bytesToWrite
                 withMessage:(NSString *)message
{
    [_progressView setProgress:(double)bytesWritten/(double)bytesToWrite
                          animated:YES];
}
-(void)showDownloadStatus:(NSString *)status withDescription:(NSString *)errorDetails
{
    _lblStatus.text = status;
}

@end
