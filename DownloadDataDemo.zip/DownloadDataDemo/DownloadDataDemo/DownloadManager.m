//
//  DownloadManager.m
//  DownloadDataDemo
//
//  Created by Prerna on 3/14/17.
//  Copyright © 2017 Narola Infotech. All rights reserved.
//

#import "DownloadManager.h"
#import "FileDownloadObject.h"
#import "AppDelegate.h"
#import <UserNotifications/UserNotifications.h>
#import "SSZipArchive.h"

@interface DownloadManager ()
    
@end

@implementation DownloadManager
Boolean is_Zip=0;
@synthesize downloadDelegate;
@synthesize download_Task;
    
    
-(id)initDownloadTask:(NSString *)urlString withZip:(Boolean)isZip withDelegate:(id<DownloadAccessories>)delegate
    {
        is_Zip = isZip;
        self.downloadDelegate = delegate;
        NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfiguration delegate:self delegateQueue:[NSOperationQueue mainQueue]];
         download_Task = [session downloadTaskWithURL:[NSURL URLWithString:urlString]];
        [download_Task resume];
        return 0;
    }
    
- (IBAction)pauseDownload:(id)sender {
    if (nil != download_Task){
        [download_Task suspend];
    }
}
- (IBAction)resumeDownload:(id)sender {
    if (nil != download_Task){
        [download_Task resume];
    }
}
- (IBAction)cancelDownload:(id)sender {
    if (nil != download_Task){
        [download_Task cancel];
    }
}
#pragma mark - NSURLSession Delegate method implementation
    
-(void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didFinishDownloadingToURL:(NSURL *)location
    {
        NSError *error;
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSString *destinationFilename = downloadTask.originalRequest.URL.lastPathComponent;
        NSURL *destinationURL = [[DownloadManager getDocumentPath] URLByAppendingPathComponent:destinationFilename];
        
        if ([fileManager fileExistsAtPath:[destinationURL path]])
        {
            [fileManager removeItemAtURL:destinationURL error:nil];
        }
        BOOL success = [fileManager copyItemAtURL:location
                                            toURL:destinationURL
                                            error:&error];
        if (success)
        {
            NSLog(@"File is copied");
            [self.downloadDelegate showDownloadStatus:@"Copy Successful" withDescription:@"No Error"];
            if(is_Zip)
            {
               [self unzipFile:destinationURL];
            }
        }
        else
        {
            NSLog(@"Unable to copy temp file. Error: %@", [error localizedDescription]);
            [self.downloadDelegate showDownloadStatus:@"Copy Failed" withDescription:[error localizedDescription]];
        }
    }
    
    
-(void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error
    {
        if (error != nil)
        {
            [self.downloadDelegate showDownloadStatus:@"Download completed with error" withDescription:[error localizedDescription]];
        }
        else
        {
            [self.downloadDelegate showDownloadStatus:@"Download finished successfully." withDescription:nil];
        }
    }
    
    
-(void)URLSession:(NSURLSession *)session
     downloadTask:(NSURLSessionDownloadTask *)downloadTask
     didWriteData:(int64_t)bytesWritten
totalBytesWritten:(int64_t)totalBytesWritten
totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite
    {
        if (totalBytesExpectedToWrite == NSURLSessionTransferSizeUnknown)
        {
            [self.downloadDelegate getDownloadStatistics:0.0
                                        withBytesWritten:0.0
                                        withBytesToWrite:0.0
                                             withMessage:@"Unknown transfer size"];
        }
        else
        {
            double totalBytes= (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
            [self.downloadDelegate getDownloadStatistics:totalBytes
                                        withBytesWritten:totalBytesWritten
                                        withBytesToWrite:totalBytesExpectedToWrite
                                             withMessage:nil];
        }
    }
    
    
-(void)URLSessionDidFinishEventsForBackgroundURLSession:(NSURLSession *)session
    {
        AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
        [session getTasksWithCompletionHandler:^(NSArray *dataTasks, NSArray *uploadTasks, NSArray *downloadTasks)
         {
             if ([downloadTasks count] == 0)
             {
                 if (appDelegate.backgroundTransferCompletionHandler != nil)
                 {
                     void(^completionHandler)() = appDelegate.backgroundTransferCompletionHandler;
                     appDelegate.backgroundTransferCompletionHandler = nil;
                     
                     [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                         completionHandler();
                         UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
                         [center requestAuthorizationWithOptions:(UNAuthorizationOptionBadge | UNAuthorizationOptionSound | UNAuthorizationOptionAlert)
                                               completionHandler:^(BOOL granted, NSError * _Nullable error) {
                                                   if (!error)
                                                   {
                                                       NSLog(@"request succeeded!");
                                                   }
                                               }];
                     }];
                 }
             }
         }];
    }
#pragma mark - SSZipArchive
- (void)unzipFile:(NSURL*)zipUrl
    {
        NSError *error;
        BOOL isFound = [[NSFileManager defaultManager] fileExistsAtPath:[zipUrl path]];
        if (isFound)
        {
            [[NSFileManager defaultManager] createDirectoryAtPath:[[zipUrl URLByDeletingPathExtension] path] withIntermediateDirectories:YES attributes:nil error:&error];
            if (!error)
            {
                [SSZipArchive unzipFileAtPath:[zipUrl path] toDestination:[[zipUrl URLByDeletingPathExtension] path]];
                //NSFileManager *fileManager = [NSFileManager defaultManager];
                //[fileManager removeItemAtPath:[zipUrl path] error:&error];
            }
        }
    }
#pragma mark - General Methods
+(NSURL *)getDocumentPath
    {
        NSArray *URLs = [[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask];
        NSURL *docDirectoryURL = [URLs objectAtIndex:0];
        return docDirectoryURL;
    }
    
    @end
