//
//  DownloadManager.h
//  DownloadDataDemo
//
//  Created by Prerna on 3/14/17.
//  Copyright © 2017 Narola Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol DownloadAccessories

@required
-(void)getDownloadStatistics:(double)totalBytes
            withBytesWritten:(double)bytesWritten
            withBytesToWrite:(double)bytesToWrite
                 withMessage:(NSString *)message;
-(void)showDownloadStatus:(NSString *)status withDescription:(NSString *)errorDetails;

@end

@interface DownloadManager : UIViewController<NSURLSessionDelegate>
{
    id<DownloadAccessories> downloadDelegate;
    NSURLSessionDownloadTask *download_Task;
}
@property (nonatomic, strong) NSURLSessionDownloadTask *download_Task;
@property (nonatomic, strong) NSMutableArray *arrFileDownloadData;
@property (nonatomic)id<DownloadAccessories> downloadDelegate;
    

+(NSURL *)getDocumentPath;
-(id)initDownloadTask:(NSString *)urlString withZip:(Boolean)isZip withDelegate:(id<DownloadAccessories>)delegate;

@end
