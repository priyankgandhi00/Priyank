//
//  ViewController.h
//  DownloadDataDemo
//
//  Created by Prerna on 3/14/17.
//  Copyright © 2017 Narola Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DownloadManager.h"

@interface ViewController : UIViewController<DownloadAccessories>

@property (strong, nonatomic) IBOutlet UILabel *lblStatus;
@property (strong, nonatomic) IBOutlet UIProgressView *progressView;

- (IBAction)btnStart:(id)sender;
- (IBAction)btnStop:(id)sender;


@end

