//
//  AppDelegate.h
//  BosLeo
//
//  Created by  Gandhi on 11/03/17.
//  Copyright © 2017  Gandhi. All rights reserved.
//

//http://stackoverflow.com/questions/24305211/pch-file-in-xcode-6
//http://stackoverflow.com/questions/10239634/how-can-i-check-what-is-stored-in-my-core-data-database

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;


- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;


@end

