//
//  TraceOperations.h
//  NIPLiOSFramework
//
//  Created by Prerna on 5/28/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TraceOperations : NSObject


#define TraceError(strErr) \
[TraceOperations writeErrorLogsToFile:[NSString stringWithFormat:@"====================\nTrace: %@ \nMETHOD: %s \nLine Number:%d \nClass: %@ \nError Description: %@", [NSDate date],  __func__, __LINE__,NSStringFromClass([self class]),strErr]];

#define TraceWS(requestURL,ParamsDictionary,serviceType) \
[TraceOperations writeWSLogsToFile:[NSString stringWithFormat:@"====================\nTrace: %@ \nService URL:%@ \nService Type: %@ \nParameters: %@ \nRequestedController:%@", [NSDate date],requestURL,serviceType,ParamsDictionary,[Function topMostController].class]];

#define TraceFlow()\
[TraceOperations writeFlowLogsToFile:[NSString stringWithFormat:@"====================\nTrace: %@ \nMETHOD: %s \nClass: %@", [NSDate date],  __func__,NSStringFromClass([self class])]];


#pragma mark - methods to log trace
+ (void)writeToFile:(NSString*)strErr withFileName:(NSString *)filename;
+ (NSString*)readFile:(NSString *)filename;


#pragma mark - trace errors
+ (void)writeErrorLogsToFile:(NSString*)strErr;
+ (NSString*)readErrorFile;


#pragma mark - trace webservice flow
+ (void)writeWSLogsToFile:(NSString*)strErr;
+ (NSString*)readWSLogFile;

#pragma mark - trace App flow
+ (void)writeFlowLogsToFile:(NSString*)strErr;
+ (NSString*)readFlowLogFile;
@end
