#import "_Favorites.h"

@interface Favorites : _Favorites {}
// Custom logic goes here.
@end
