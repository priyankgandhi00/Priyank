//
//  HomePageConfig.m
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "HomePageConfig.h"


NSString *const kHomePageConfigModifiedTimestamp = @"modified_timestamp";
NSString *const kHomePageConfigConfigId = @"config_id";
NSString *const kHomePageConfigUserProfileId = @"user_profile_id";
NSString *const kHomePageConfigModifiedBy = @"modified_by";


@interface HomePageConfig ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation HomePageConfig

@synthesize modifiedTimestamp = _modifiedTimestamp;
@synthesize configId = _configId;
@synthesize userProfileId = _userProfileId;
@synthesize modifiedBy = _modifiedBy;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.modifiedTimestamp = [self objectOrNilForKey:kHomePageConfigModifiedTimestamp fromDictionary:dict];
            self.configId = [self objectOrNilForKey:kHomePageConfigConfigId fromDictionary:dict];
            self.userProfileId = [self objectOrNilForKey:kHomePageConfigUserProfileId fromDictionary:dict];
            self.modifiedBy = [self objectOrNilForKey:kHomePageConfigModifiedBy fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.modifiedTimestamp forKey:kHomePageConfigModifiedTimestamp];
    [mutableDict setValue:self.configId forKey:kHomePageConfigConfigId];
    [mutableDict setValue:self.userProfileId forKey:kHomePageConfigUserProfileId];
    [mutableDict setValue:self.modifiedBy forKey:kHomePageConfigModifiedBy];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.modifiedTimestamp = [aDecoder decodeObjectForKey:kHomePageConfigModifiedTimestamp];
    self.configId = [aDecoder decodeObjectForKey:kHomePageConfigConfigId];
    self.userProfileId = [aDecoder decodeObjectForKey:kHomePageConfigUserProfileId];
    self.modifiedBy = [aDecoder decodeObjectForKey:kHomePageConfigModifiedBy];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_modifiedTimestamp forKey:kHomePageConfigModifiedTimestamp];
    [aCoder encodeObject:_configId forKey:kHomePageConfigConfigId];
    [aCoder encodeObject:_userProfileId forKey:kHomePageConfigUserProfileId];
    [aCoder encodeObject:_modifiedBy forKey:kHomePageConfigModifiedBy];
}

- (id)copyWithZone:(NSZone *)zone
{
    HomePageConfig *copy = [[HomePageConfig alloc] init];
    
    if (copy) {

        copy.modifiedTimestamp = [self.modifiedTimestamp copyWithZone:zone];
        copy.configId = [self.configId copyWithZone:zone];
        copy.userProfileId = [self.userProfileId copyWithZone:zone];
        copy.modifiedBy = [self.modifiedBy copyWithZone:zone];
    }
    
    return copy;
}


@end
