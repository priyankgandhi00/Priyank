//
//  Tiles.m
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "Tiles.h"


NSString *const kTilesTileId = @"tile_id";
NSString *const kTilesTagImage = @"tag_image";
NSString *const kTilesConfigId = @"config_id";
NSString *const kTilesTagId = @"tag_id";
NSString *const kTilesPosition = @"position";
NSString *const kTilesTagDesc = @"tag_desc";


@interface Tiles ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Tiles

@synthesize tileId = _tileId;
@synthesize tagImage = _tagImage;
@synthesize configId = _configId;
@synthesize tagId = _tagId;
@synthesize position = _position;
@synthesize tagDesc = _tagDesc;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.tileId = [self objectOrNilForKey:kTilesTileId fromDictionary:dict];
            self.tagImage = [self objectOrNilForKey:kTilesTagImage fromDictionary:dict];
            self.configId = [self objectOrNilForKey:kTilesConfigId fromDictionary:dict];
            self.tagId = [self objectOrNilForKey:kTilesTagId fromDictionary:dict];
            self.position = [self objectOrNilForKey:kTilesPosition fromDictionary:dict];
            self.tagDesc = [self objectOrNilForKey:kTilesTagDesc fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.tileId forKey:kTilesTileId];
    [mutableDict setValue:self.tagImage forKey:kTilesTagImage];
    [mutableDict setValue:self.configId forKey:kTilesConfigId];
    [mutableDict setValue:self.tagId forKey:kTilesTagId];
    [mutableDict setValue:self.position forKey:kTilesPosition];
    [mutableDict setValue:self.tagDesc forKey:kTilesTagDesc];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.tileId = [aDecoder decodeObjectForKey:kTilesTileId];
    self.tagImage = [aDecoder decodeObjectForKey:kTilesTagImage];
    self.configId = [aDecoder decodeObjectForKey:kTilesConfigId];
    self.tagId = [aDecoder decodeObjectForKey:kTilesTagId];
    self.position = [aDecoder decodeObjectForKey:kTilesPosition];
    self.tagDesc = [aDecoder decodeObjectForKey:kTilesTagDesc];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_tileId forKey:kTilesTileId];
    [aCoder encodeObject:_tagImage forKey:kTilesTagImage];
    [aCoder encodeObject:_configId forKey:kTilesConfigId];
    [aCoder encodeObject:_tagId forKey:kTilesTagId];
    [aCoder encodeObject:_position forKey:kTilesPosition];
    [aCoder encodeObject:_tagDesc forKey:kTilesTagDesc];
}

- (id)copyWithZone:(NSZone *)zone
{
    Tiles *copy = [[Tiles alloc] init];
    
    if (copy) {

        copy.tileId = [self.tileId copyWithZone:zone];
        copy.tagImage = [self.tagImage copyWithZone:zone];
        copy.configId = [self.configId copyWithZone:zone];
        copy.tagId = [self.tagId copyWithZone:zone];
        copy.position = [self.position copyWithZone:zone];
        copy.tagDesc = [self.tagDesc copyWithZone:zone];
    }
    
    return copy;
}


@end
