#import "_Restaurant.h"
//#import "ModelContants.h"
#import <CoreData/CoreData.h>


@interface FamousFoodWS : NSObject


@property (copy) NSString *call;
@property (copy) NSString *famousFoodDescription;
@property (copy) NSString *timing;
@property (copy) NSString *location;
@property (copy) NSString *ratings;
@property (copy) NSString *foodName;
@property (copy) NSArray  *images;
@property (copy) NSString *sitting;
@property (copy) NSString *numberOfReviews;
@property (copy) NSString *title;
@property (copy) NSString *partyOrder;
@property (copy) NSString *landmark;
@property (copy) NSString *areaId;
@property (copy) NSString *foodID;
@property (copy) NSString *vegNonVeg;

#pragma mark - webservice helper
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;
@end
