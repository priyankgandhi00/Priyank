//
//  QuestionSets.m
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "QuestionSets.h"
#import "Answers.h"


NSString *const kQuestionSetsQuestionFormat = @"question_format";
NSString *const kQuestionSetsQuestionSetsId = @"question_sets_id";
NSString *const kQuestionSetsQuestionUpdateDatetime = @"question_update_datetime";
NSString *const kQuestionSetsQuestionPublicPrivateFlag = @"question_public_private_flag";
NSString *const kQuestionSetsQuestionAudioLink = @"question_audio_link";
NSString *const kQuestionSetsDifficultyId = @"difficulty_id";
NSString *const kQuestionSetsQuestionTitle = @"question_title";
NSString *const kQuestionSetsQuestionCreatorUserId = @"question_creator_user_id";
NSString *const kQuestionSetsAnswerChoiceTypeId = @"answer_choice_type_id";
NSString *const kQuestionSetsAnswers = @"answers";
NSString *const kQuestionSetsTagImage = @"tag_image";
NSString *const kQuestionSetsQuestionId = @"question_id";
NSString *const kQuestionSetsQuestionAssetsLink = @"question_assets_link";
NSString *const kQuestionSetsQuestionAssetName = @"question_asset_name";
NSString *const kQuestionSetsIsActive = @"is_active";
NSString *const kQuestionSetsTagId = @"tag_id";
NSString *const kQuestionSetsQuestionCreationDatetime = @"question_creation_datetime";
NSString *const kQuestionSetsQuestionCorrectAnswerType = @"question_correct_answer_type";
NSString *const kQuestionSetsTagDesc = @"tag_desc";
NSString *const kQuestionSetsQuestionTitleHint = @"question_title_hint";


@interface QuestionSets ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation QuestionSets

@synthesize questionFormat = _questionFormat;
@synthesize questionSetsId = _questionSetsId;
@synthesize questionUpdateDatetime = _questionUpdateDatetime;
@synthesize questionPublicPrivateFlag = _questionPublicPrivateFlag;
@synthesize questionAudioLink = _questionAudioLink;
@synthesize difficultyId = _difficultyId;
@synthesize questionTitle = _questionTitle;
@synthesize questionCreatorUserId = _questionCreatorUserId;
@synthesize answerChoiceTypeId = _answerChoiceTypeId;
@synthesize answers = _answers;
@synthesize tagImage = _tagImage;
@synthesize questionId = _questionId;
@synthesize questionAssetsLink = _questionAssetsLink;
@synthesize questionAssetName = _questionAssetName;
@synthesize isActive = _isActive;
@synthesize tagId = _tagId;
@synthesize questionCreationDatetime = _questionCreationDatetime;
@synthesize questionCorrectAnswerType = _questionCorrectAnswerType;
@synthesize tagDesc = _tagDesc;
@synthesize questionTitleHint = _questionTitleHint;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.questionFormat = [self objectOrNilForKey:kQuestionSetsQuestionFormat fromDictionary:dict];
            self.questionSetsId = [self objectOrNilForKey:kQuestionSetsQuestionSetsId fromDictionary:dict];
            self.questionUpdateDatetime = [self objectOrNilForKey:kQuestionSetsQuestionUpdateDatetime fromDictionary:dict];
            self.questionPublicPrivateFlag = [self objectOrNilForKey:kQuestionSetsQuestionPublicPrivateFlag fromDictionary:dict];
            self.questionAudioLink = [self objectOrNilForKey:kQuestionSetsQuestionAudioLink fromDictionary:dict];
            self.difficultyId = [self objectOrNilForKey:kQuestionSetsDifficultyId fromDictionary:dict];
            self.questionTitle = [self objectOrNilForKey:kQuestionSetsQuestionTitle fromDictionary:dict];
            self.questionCreatorUserId = [self objectOrNilForKey:kQuestionSetsQuestionCreatorUserId fromDictionary:dict];
            self.answerChoiceTypeId = [self objectOrNilForKey:kQuestionSetsAnswerChoiceTypeId fromDictionary:dict];
    NSObject *receivedAnswers = [dict objectForKey:kQuestionSetsAnswers];
    NSMutableArray *parsedAnswers = [NSMutableArray array];
    if ([receivedAnswers isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedAnswers) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedAnswers addObject:[Answers modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedAnswers isKindOfClass:[NSDictionary class]]) {
       [parsedAnswers addObject:[Answers modelObjectWithDictionary:(NSDictionary *)receivedAnswers]];
    }

    self.answers = [NSArray arrayWithArray:parsedAnswers];
            self.tagImage = [self objectOrNilForKey:kQuestionSetsTagImage fromDictionary:dict];
            self.questionId = [self objectOrNilForKey:kQuestionSetsQuestionId fromDictionary:dict];
            self.questionAssetsLink = [self objectOrNilForKey:kQuestionSetsQuestionAssetsLink fromDictionary:dict];
            self.questionAssetName = [self objectOrNilForKey:kQuestionSetsQuestionAssetName fromDictionary:dict];
            self.isActive = [self objectOrNilForKey:kQuestionSetsIsActive fromDictionary:dict];
            self.tagId = [self objectOrNilForKey:kQuestionSetsTagId fromDictionary:dict];
            self.questionCreationDatetime = [self objectOrNilForKey:kQuestionSetsQuestionCreationDatetime fromDictionary:dict];
            self.questionCorrectAnswerType = [self objectOrNilForKey:kQuestionSetsQuestionCorrectAnswerType fromDictionary:dict];
            self.tagDesc = [self objectOrNilForKey:kQuestionSetsTagDesc fromDictionary:dict];
            self.questionTitleHint = [self objectOrNilForKey:kQuestionSetsQuestionTitleHint fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.questionFormat forKey:kQuestionSetsQuestionFormat];
    [mutableDict setValue:self.questionSetsId forKey:kQuestionSetsQuestionSetsId];
    [mutableDict setValue:self.questionUpdateDatetime forKey:kQuestionSetsQuestionUpdateDatetime];
    [mutableDict setValue:self.questionPublicPrivateFlag forKey:kQuestionSetsQuestionPublicPrivateFlag];
    [mutableDict setValue:self.questionAudioLink forKey:kQuestionSetsQuestionAudioLink];
    [mutableDict setValue:self.difficultyId forKey:kQuestionSetsDifficultyId];
    [mutableDict setValue:self.questionTitle forKey:kQuestionSetsQuestionTitle];
    [mutableDict setValue:self.questionCreatorUserId forKey:kQuestionSetsQuestionCreatorUserId];
    [mutableDict setValue:self.answerChoiceTypeId forKey:kQuestionSetsAnswerChoiceTypeId];
    NSMutableArray *tempArrayForAnswers = [NSMutableArray array];
    for (NSObject *subArrayObject in self.answers) {
        if([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForAnswers addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForAnswers addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForAnswers] forKey:kQuestionSetsAnswers];
    [mutableDict setValue:self.tagImage forKey:kQuestionSetsTagImage];
    [mutableDict setValue:self.questionId forKey:kQuestionSetsQuestionId];
    [mutableDict setValue:self.questionAssetsLink forKey:kQuestionSetsQuestionAssetsLink];
    [mutableDict setValue:self.questionAssetName forKey:kQuestionSetsQuestionAssetName];
    [mutableDict setValue:self.isActive forKey:kQuestionSetsIsActive];
    [mutableDict setValue:self.tagId forKey:kQuestionSetsTagId];
    [mutableDict setValue:self.questionCreationDatetime forKey:kQuestionSetsQuestionCreationDatetime];
    [mutableDict setValue:self.questionCorrectAnswerType forKey:kQuestionSetsQuestionCorrectAnswerType];
    [mutableDict setValue:self.tagDesc forKey:kQuestionSetsTagDesc];
    [mutableDict setValue:self.questionTitleHint forKey:kQuestionSetsQuestionTitleHint];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.questionFormat = [aDecoder decodeObjectForKey:kQuestionSetsQuestionFormat];
    self.questionSetsId = [aDecoder decodeObjectForKey:kQuestionSetsQuestionSetsId];
    self.questionUpdateDatetime = [aDecoder decodeObjectForKey:kQuestionSetsQuestionUpdateDatetime];
    self.questionPublicPrivateFlag = [aDecoder decodeObjectForKey:kQuestionSetsQuestionPublicPrivateFlag];
    self.questionAudioLink = [aDecoder decodeObjectForKey:kQuestionSetsQuestionAudioLink];
    self.difficultyId = [aDecoder decodeObjectForKey:kQuestionSetsDifficultyId];
    self.questionTitle = [aDecoder decodeObjectForKey:kQuestionSetsQuestionTitle];
    self.questionCreatorUserId = [aDecoder decodeObjectForKey:kQuestionSetsQuestionCreatorUserId];
    self.answerChoiceTypeId = [aDecoder decodeObjectForKey:kQuestionSetsAnswerChoiceTypeId];
    self.answers = [aDecoder decodeObjectForKey:kQuestionSetsAnswers];
    self.tagImage = [aDecoder decodeObjectForKey:kQuestionSetsTagImage];
    self.questionId = [aDecoder decodeObjectForKey:kQuestionSetsQuestionId];
    self.questionAssetsLink = [aDecoder decodeObjectForKey:kQuestionSetsQuestionAssetsLink];
    self.questionAssetName = [aDecoder decodeObjectForKey:kQuestionSetsQuestionAssetName];
    self.isActive = [aDecoder decodeObjectForKey:kQuestionSetsIsActive];
    self.tagId = [aDecoder decodeObjectForKey:kQuestionSetsTagId];
    self.questionCreationDatetime = [aDecoder decodeObjectForKey:kQuestionSetsQuestionCreationDatetime];
    self.questionCorrectAnswerType = [aDecoder decodeObjectForKey:kQuestionSetsQuestionCorrectAnswerType];
    self.tagDesc = [aDecoder decodeObjectForKey:kQuestionSetsTagDesc];
    self.questionTitleHint = [aDecoder decodeObjectForKey:kQuestionSetsQuestionTitleHint];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_questionFormat forKey:kQuestionSetsQuestionFormat];
    [aCoder encodeObject:_questionSetsId forKey:kQuestionSetsQuestionSetsId];
    [aCoder encodeObject:_questionUpdateDatetime forKey:kQuestionSetsQuestionUpdateDatetime];
    [aCoder encodeObject:_questionPublicPrivateFlag forKey:kQuestionSetsQuestionPublicPrivateFlag];
    [aCoder encodeObject:_questionAudioLink forKey:kQuestionSetsQuestionAudioLink];
    [aCoder encodeObject:_difficultyId forKey:kQuestionSetsDifficultyId];
    [aCoder encodeObject:_questionTitle forKey:kQuestionSetsQuestionTitle];
    [aCoder encodeObject:_questionCreatorUserId forKey:kQuestionSetsQuestionCreatorUserId];
    [aCoder encodeObject:_answerChoiceTypeId forKey:kQuestionSetsAnswerChoiceTypeId];
    [aCoder encodeObject:_answers forKey:kQuestionSetsAnswers];
    [aCoder encodeObject:_tagImage forKey:kQuestionSetsTagImage];
    [aCoder encodeObject:_questionId forKey:kQuestionSetsQuestionId];
    [aCoder encodeObject:_questionAssetsLink forKey:kQuestionSetsQuestionAssetsLink];
    [aCoder encodeObject:_questionAssetName forKey:kQuestionSetsQuestionAssetName];
    [aCoder encodeObject:_isActive forKey:kQuestionSetsIsActive];
    [aCoder encodeObject:_tagId forKey:kQuestionSetsTagId];
    [aCoder encodeObject:_questionCreationDatetime forKey:kQuestionSetsQuestionCreationDatetime];
    [aCoder encodeObject:_questionCorrectAnswerType forKey:kQuestionSetsQuestionCorrectAnswerType];
    [aCoder encodeObject:_tagDesc forKey:kQuestionSetsTagDesc];
    [aCoder encodeObject:_questionTitleHint forKey:kQuestionSetsQuestionTitleHint];
}

- (id)copyWithZone:(NSZone *)zone
{
    QuestionSets *copy = [[QuestionSets alloc] init];
    
    if (copy) {

        copy.questionFormat = [self.questionFormat copyWithZone:zone];
        copy.questionSetsId = [self.questionSetsId copyWithZone:zone];
        copy.questionUpdateDatetime = [self.questionUpdateDatetime copyWithZone:zone];
        copy.questionPublicPrivateFlag = [self.questionPublicPrivateFlag copyWithZone:zone];
        copy.questionAudioLink = [self.questionAudioLink copyWithZone:zone];
        copy.difficultyId = [self.difficultyId copyWithZone:zone];
        copy.questionTitle = [self.questionTitle copyWithZone:zone];
        copy.questionCreatorUserId = [self.questionCreatorUserId copyWithZone:zone];
        copy.answerChoiceTypeId = [self.answerChoiceTypeId copyWithZone:zone];
        copy.answers = [self.answers copyWithZone:zone];
        copy.tagImage = [self.tagImage copyWithZone:zone];
        copy.questionId = [self.questionId copyWithZone:zone];
        copy.questionAssetsLink = [self.questionAssetsLink copyWithZone:zone];
        copy.questionAssetName = [self.questionAssetName copyWithZone:zone];
        copy.isActive = [self.isActive copyWithZone:zone];
        copy.tagId = [self.tagId copyWithZone:zone];
        copy.questionCreationDatetime = [self.questionCreationDatetime copyWithZone:zone];
        copy.questionCorrectAnswerType = [self.questionCorrectAnswerType copyWithZone:zone];
        copy.tagDesc = [self.tagDesc copyWithZone:zone];
        copy.questionTitleHint = [self.questionTitleHint copyWithZone:zone];
    }
    
    return copy;
}


@end
