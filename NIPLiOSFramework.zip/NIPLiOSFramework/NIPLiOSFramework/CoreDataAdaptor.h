//
//  CoreDataWrapper.h
//  NIPLiOSFramework
//
//  Created by Prerna on 5/21/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreDataAdaptor : NSObject
+ (void)SaveDataInCoreDB:(NSDictionary *)dict forEntity:(NSString *)entityname;
+ (void)SaveRestaurantInCoreDB:(NSDictionary *)dict;

+(void)deleteDataInCoreDB:(NSString *)entityname withCondition:(NSString *)condition;
+(void)deleteAllDataInCoreDB:(NSString *)entityname;
+ (void)updateRecords: (NSString *) condition;


+ (NSArray *) fetchRestaurantWhere:(NSString *)condition;
+ (NSArray *) fetchAllRestaurant;
+ (void)MapNSObjectToNSManagedObject:(NSString *)objClass forEntityName:(NSManagedObject *)entityname withDataSource:(NSMutableArray *)array;
+(NSInteger)getRecordCount: (NSString *)entityname;
@end
