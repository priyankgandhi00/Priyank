//
//  Answers.m
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "Answers.h"


NSString *const kAnswersChoice = @"choice";
NSString *const kAnswersChoiceFeedback = @"choice_feedback";
NSString *const kAnswersChoiceId = @"choice_id";
NSString *const kAnswersImageLink = @"image_link";
NSString *const kAnswersIsRight = @"is_right";
NSString *const kAnswersQuestionId = @"question_id";
NSString *const kAnswersAudioLink = @"audio_link";
NSString *const kAnswersVideoLink = @"video_link";
NSString *const kAnswersText = @"text";


@interface Answers ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Answers

@synthesize choice = _choice;
@synthesize choiceFeedback = _choiceFeedback;
@synthesize choiceId = _choiceId;
@synthesize imageLink = _imageLink;
@synthesize isRight = _isRight;
@synthesize questionId = _questionId;
@synthesize audioLink = _audioLink;
@synthesize videoLink = _videoLink;
@synthesize text = _text;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.choice = [self objectOrNilForKey:kAnswersChoice fromDictionary:dict];
            self.choiceFeedback = [self objectOrNilForKey:kAnswersChoiceFeedback fromDictionary:dict];
            self.choiceId = [self objectOrNilForKey:kAnswersChoiceId fromDictionary:dict];
            self.imageLink = [self objectOrNilForKey:kAnswersImageLink fromDictionary:dict];
            self.isRight = [self objectOrNilForKey:kAnswersIsRight fromDictionary:dict];
            self.questionId = [self objectOrNilForKey:kAnswersQuestionId fromDictionary:dict];
            self.audioLink = [self objectOrNilForKey:kAnswersAudioLink fromDictionary:dict];
            self.videoLink = [self objectOrNilForKey:kAnswersVideoLink fromDictionary:dict];
            self.text = [self objectOrNilForKey:kAnswersText fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.choice forKey:kAnswersChoice];
    [mutableDict setValue:self.choiceFeedback forKey:kAnswersChoiceFeedback];
    [mutableDict setValue:self.choiceId forKey:kAnswersChoiceId];
    [mutableDict setValue:self.imageLink forKey:kAnswersImageLink];
    [mutableDict setValue:self.isRight forKey:kAnswersIsRight];
    [mutableDict setValue:self.questionId forKey:kAnswersQuestionId];
    [mutableDict setValue:self.audioLink forKey:kAnswersAudioLink];
    [mutableDict setValue:self.videoLink forKey:kAnswersVideoLink];
    [mutableDict setValue:self.text forKey:kAnswersText];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.choice = [aDecoder decodeObjectForKey:kAnswersChoice];
    self.choiceFeedback = [aDecoder decodeObjectForKey:kAnswersChoiceFeedback];
    self.choiceId = [aDecoder decodeObjectForKey:kAnswersChoiceId];
    self.imageLink = [aDecoder decodeObjectForKey:kAnswersImageLink];
    self.isRight = [aDecoder decodeObjectForKey:kAnswersIsRight];
    self.questionId = [aDecoder decodeObjectForKey:kAnswersQuestionId];
    self.audioLink = [aDecoder decodeObjectForKey:kAnswersAudioLink];
    self.videoLink = [aDecoder decodeObjectForKey:kAnswersVideoLink];
    self.text = [aDecoder decodeObjectForKey:kAnswersText];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_choice forKey:kAnswersChoice];
    [aCoder encodeObject:_choiceFeedback forKey:kAnswersChoiceFeedback];
    [aCoder encodeObject:_choiceId forKey:kAnswersChoiceId];
    [aCoder encodeObject:_imageLink forKey:kAnswersImageLink];
    [aCoder encodeObject:_isRight forKey:kAnswersIsRight];
    [aCoder encodeObject:_questionId forKey:kAnswersQuestionId];
    [aCoder encodeObject:_audioLink forKey:kAnswersAudioLink];
    [aCoder encodeObject:_videoLink forKey:kAnswersVideoLink];
    [aCoder encodeObject:_text forKey:kAnswersText];
}

- (id)copyWithZone:(NSZone *)zone
{
    Answers *copy = [[Answers alloc] init];
    
    if (copy) {

        copy.choice = [self.choice copyWithZone:zone];
        copy.choiceFeedback = [self.choiceFeedback copyWithZone:zone];
        copy.choiceId = [self.choiceId copyWithZone:zone];
        copy.imageLink = [self.imageLink copyWithZone:zone];
        copy.isRight = [self.isRight copyWithZone:zone];
        copy.questionId = [self.questionId copyWithZone:zone];
        copy.audioLink = [self.audioLink copyWithZone:zone];
        copy.videoLink = [self.videoLink copyWithZone:zone];
        copy.text = [self.text copyWithZone:zone];
    }
    
    return copy;
}


@end
