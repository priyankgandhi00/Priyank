//
//  ViewController.m
//  NIPLiOSFramework
//
//  Created by Prerna on 5/13/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//
// to call webservices with parameters:
    //    [[WebServiceConnector alloc]init:GetEmployeeList
    //                      withParameters:@{@"EmpID": @"1",@"EmpName":@"Prerna"}
    //                          withObject:self
    //                        withSelector:@selector(DisplayEmp:)];
// to call SQL with parameters:
    //    [SQLDataHelper ExecuteInsert:tblEmpMaster
    //                  withParameters:@{@"empId":@"2",@"empname":@"Milan"}];
    //


#import "WSViewController.h"
#import "AppDelegate.h"
#import "WebServiceConnector.h"
#import "Constants.h"
//#import "FamousFood.h"
#import "Restaurant.h"
#import "FamousFoodWS.h"
#import "TraceOperations.h"
#import "ReachabilityManager.h"
#import "NSString+Extensions.h"


@interface WSViewController ()
@end

@implementation WSViewController
@synthesize arrdataSource;

- (void)viewDidLoad
{
    [super viewDidLoad];
    arrdataSource = [NSMutableArray new];
    TraceFlow()
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
- (IBAction)btnWSGet:(id)sender
{
    if([ReachabilityManager isReachable])
    {
        [[WebServiceConnector alloc]init:URLGetFamousFood
                          withParameters:nil
                              withObject:self
                            withSelector:@selector(DisplayEmp:)
                          forServiceType:@"GET"
                          showDisplayMsg:GetFamousFoodMsg];
    }
    else
    {
    }
}

- (IBAction)btnWSPost:(id)sender
{
    if([ReachabilityManager isReachable])
    { 
        [[WebServiceConnector alloc]init:URLGetSetsWithQuestions
                          withParameters:@{@"tag_id":@"9",
                                           @"DefaultQuestionLastSyncDate":@"2015-04-04 11:03:12",
                                           @"user_id":@"3"}
                              withObject:self withSelector:@selector(DisplayEmp:) forServiceType:@"POST" showDisplayMsg:GetFamousFoodMsg];
        
    }
    else
    {
    }

}

- (IBAction)btnWSUpload:(id)sender
{
    //Navigates to UploadESDEmoVC via seagues
}

- (IBAction)btnWSJson:(id)sender
{
    if([ReachabilityManager isReachable])
    {
        [[WebServiceConnector alloc]init:URLAddProfile
                          withParameters:@{@"profile_fname":@"baby girl first name",
                                           @"profile_lname":@"baby girl last name",
                                           @"profile_status":@"1",
                                           @"profile_added_by_user":@"1",
                                           @"profile_age":@"5"}
                              withObject:self
                            withSelector:@selector(DisplayEmp:)
                          forServiceType:@"JSON"
                          showDisplayMsg:GetFamousFoodMsg];
    }
    else
    {
    }
}

- (IBAction)btnWSParseJSONKeys:(id)sender
{
    if([ReachabilityManager isReachable])
    {
        [[WebServiceConnector alloc]init:URLRegister
                          withParameters:@{@"user_email":@"prerna1234@gmail.com",
                                           @"user_password":@"password"}
                              withObject:self
                            withSelector:@selector(DisplayEmp:)
                          forServiceType:@"JSON"
                          showDisplayMsg:GetFamousFoodMsg];
    }
    else
    {
    }
}

- (void)DisplayFromCoreDB
{

    NSArray *arrfood = [[Restaurant query] all];
    //NSArray *arrfood = [[FamousFood query]where:@"areaId='16'"].all;
    for (int i=0; i<[arrfood count]; i++)
    {
        FamousFoodWS *obj = [arrfood objectAtIndex:i];
        NSLog(@"Restaurant:%@,%@,%@",obj.title,obj.foodName, obj.location);
    }
    arrdataSource = [arrfood mutableCopy];
    [_tblData reloadData];
}

- (void)DisplayEmp:(id)sender
{
    [SVProgressHUD dismiss];
    if ([sender responseCode] != 100)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:[sender responseError] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
    }
    else
    {
        NSLog(@"%@", [sender responseArray]);
        NSLog(@"%@", [sender responseDict]);
        //[self DisplayFromCoreDB];
       
        for (int i =0 ; i<[[sender responseArray] count]; i++)
        {
            FamousFoodWS *food = [[sender responseArray] objectAtIndex:i];
            NSLog(@"Title: %@",food.title);
            NSLog(@"Location: %@",food.location);
        }
        
    }
}


#pragma mark - tableview methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrdataSource count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    FamousFoodWS *obj = [arrdataSource objectAtIndex:indexPath.row];
    cell.textLabel.text = obj.title;
    cell.detailTextLabel.text = obj.location;
    
    return cell;
}
@end
