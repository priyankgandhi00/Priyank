// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to Images.m instead.

#import "_Images.h"

const struct ImagesAttributes ImagesAttributes = {
	.imageid = @"imageid",
	.imagename = @"imagename",
};

const struct ImagesRelationships ImagesRelationships = {
	.restrodetail = @"restrodetail",
};

@implementation ImagesID
@end

@implementation _Images

+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"Images" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"Images";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"Images" inManagedObjectContext:moc_];
}

- (ImagesID*)objectID {
	return (ImagesID*)[super objectID];
}

+ (NSSet*)keyPathsForValuesAffectingValueForKey:(NSString*)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];

	if ([key isEqualToString:@"imageidValue"]) {
		NSSet *affectingKey = [NSSet setWithObject:@"imageid"];
		keyPaths = [keyPaths setByAddingObjectsFromSet:affectingKey];
		return keyPaths;
	}

	return keyPaths;
}

@dynamic imageid;

- (int16_t)imageidValue {
	NSNumber *result = [self imageid];
	return [result shortValue];
}

- (void)setImageidValue:(int16_t)value_ {
	[self setImageid:[NSNumber numberWithShort:value_]];
}

- (int16_t)primitiveImageidValue {
	NSNumber *result = [self primitiveImageid];
	return [result shortValue];
}

- (void)setPrimitiveImageidValue:(int16_t)value_ {
	[self setPrimitiveImageid:[NSNumber numberWithShort:value_]];
}

@dynamic imagename;

@dynamic restrodetail;

@end

