//
//  ProfileDetails.h
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface ProfileDetails : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *profileAge;
@property (nonatomic, strong) NSString *profileStatus;
@property (nonatomic, strong) NSString *userProfileId;
@property (nonatomic, strong) NSString *profileId;
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *profileImage;
@property (nonatomic, strong) NSArray *monitors;
@property (nonatomic, strong) NSString *profileLname;
@property (nonatomic, assign) id profileDob;
@property (nonatomic, strong) NSArray *tiles;
@property (nonatomic, strong) NSString *profileFname;
@property (nonatomic, strong) NSString *userProfilePermissionStatus;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
