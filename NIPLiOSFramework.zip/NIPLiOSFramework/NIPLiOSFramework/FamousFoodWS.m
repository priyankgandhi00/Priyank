#import "FamousFoodWS.h"
NSString *const kFamousFoodCall = @"Call";
NSString *const kFamousFoodDescription = @"Description";
NSString *const kFamousFoodTiming = @"Timing";
NSString *const kFamousFoodLocation = @"Location";
NSString *const kFamousFoodRatings = @"Ratings";
NSString *const kFamousFoodFoodName = @"FoodName";
NSString *const kFamousFoodImages = @"Images";
NSString *const kFamousFoodSitting = @"Sitting";
NSString *const kFamousFoodNumberOfReviews = @"NumberOfReviews";
NSString *const kFamousFoodTitle = @"Title";
NSString *const kFamousFoodPartyOrder = @"PartyOrder";
NSString *const kFamousFoodLandmark = @"Landmark";
NSString *const kFamousFoodAreaId = @"AreaId";
NSString *const kFamousFoodFoodID = @"FoodID";
NSString *const kFamousFoodVegNonVeg = @"Veg_NonVeg";

@interface FamousFoodWS ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation FamousFoodWS
@synthesize call = _call;
@synthesize famousFoodDescription = _famousFoodDescription;
@synthesize timing = _timing;
@synthesize location = _location;
@synthesize ratings = _ratings;
@synthesize foodName = _foodName;
@synthesize images = _images;
@synthesize sitting = _sitting;
@synthesize numberOfReviews = _numberOfReviews;
@synthesize title = _title;
@synthesize partyOrder = _partyOrder;
@synthesize landmark = _landmark;
@synthesize areaId = _areaId;
@synthesize foodID = _foodID;
@synthesize vegNonVeg = _vegNonVeg;


#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - Parse Object

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];

    if(self && [dict isKindOfClass:[NSDictionary class]])
    {
        self.call = [self objectOrNilForKey:kFamousFoodCall fromDictionary:dict];
        self.famousFoodDescription = [self objectOrNilForKey:kFamousFoodDescription fromDictionary:dict];
        self.timing = [self objectOrNilForKey:kFamousFoodTiming fromDictionary:dict];
        self.location = [self objectOrNilForKey:kFamousFoodLocation fromDictionary:dict];
        self.ratings = [self objectOrNilForKey:kFamousFoodRatings fromDictionary:dict];
        self.foodName = [self objectOrNilForKey:kFamousFoodFoodName fromDictionary:dict];
        self.images = [self objectOrNilForKey:kFamousFoodImages fromDictionary:dict];
        self.sitting = [self objectOrNilForKey:kFamousFoodSitting fromDictionary:dict];
        self.numberOfReviews = [self objectOrNilForKey:kFamousFoodNumberOfReviews fromDictionary:dict];
        self.title = [self objectOrNilForKey:kFamousFoodTitle fromDictionary:dict];
        self.partyOrder = [self objectOrNilForKey:kFamousFoodPartyOrder fromDictionary:dict];
        self.landmark = [self objectOrNilForKey:kFamousFoodLandmark fromDictionary:dict];
        self.areaId = [self objectOrNilForKey:kFamousFoodAreaId fromDictionary:dict];
        self.foodID = [self objectOrNilForKey:kFamousFoodFoodID fromDictionary:dict];
        self.vegNonVeg = [self objectOrNilForKey:kFamousFoodVegNonVeg fromDictionary:dict];        
    }
    return self;
}
@end
