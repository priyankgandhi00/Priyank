//
//  SQLiteViewController.m
//  NIPLiOSFramework
//
//  Created by Prerna on 7/1/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import "SQLiteViewController.h"
#import "SQLDataAdapter.h"

@interface SQLiteViewController ()

@end

@implementation SQLiteViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnCopyDatabase:(id)sender
{
    [[SQLDataAdapter sharedInstance] copyDatabase];
}

- (IBAction)btnInsert:(id)sender
{
    [[SQLDataAdapter sharedInstance] insertRestaurant:@{@"RestaurantName":@"Branto",
                                                        @"Address":@"Athwalines",
                                                        @"ContactPerson":@"Ajit Sodhi",
                                                        @"ContactNumber":@"9878967787",
                                                        @"WebsiteURL":@"http://www.branto.com"}];
}

- (IBAction)btnSelectByArea:(id)sender
{
    NSLog(@"%@",[[SQLDataAdapter sharedInstance] selectRestaurantByAddress:@"Adajan"]);
}

- (IBAction)btnSelectAllRestaurant:(id)sender
{
    NSLog(@"%@",[[SQLDataAdapter sharedInstance] selectAllRestaurant]);
}

- (IBAction)btnDeleteByID:(id)sender
{
    [[SQLDataAdapter sharedInstance] deleteRestaurant:@{@"RestaurantID":@"20"}];
}

- (IBAction)btnUpdate:(id)sender
{
    [[SQLDataAdapter sharedInstance] updateRestaurant:@{@"RestaurantName":@"Branto",
                                                        @"Address":@"Athwalines",
                                                        @"ContactPerson":@"Ajit Sodhi",
                                                        @"ContactNumber":@"9878967787",
                                                        @"WebsiteURL":@"http://www.branto.com"}
                                        withCondition:@{@"RestaurantID":@"33"}];
}
@end
