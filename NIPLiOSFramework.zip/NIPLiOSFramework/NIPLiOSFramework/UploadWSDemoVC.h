//
//  UploadWSDemoVC.h
//  NIPLiOSFramework
//
//  Created by Prerna on 6/27/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import "WSViewController.h"
#import <MediaPlayer/MediaPlayer.h>

@interface UploadWSDemoVC : WSViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,MPMediaPickerControllerDelegate>


@property (strong, nonatomic) IBOutlet UIImageView *imgSelectedImage;

- (IBAction)btnBackClick:(id)sender;
- (IBAction)btnUploadProfile:(id)sender;


- (IBAction)btnUploadAudio:(id)sender;
- (IBAction)btnChoseAudio:(id)sender;

@end
