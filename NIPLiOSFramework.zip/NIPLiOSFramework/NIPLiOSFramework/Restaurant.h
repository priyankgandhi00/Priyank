#import "_Restaurant.h"

@interface Restaurant : _Restaurant {}
// Custom logic goes here.
@end
