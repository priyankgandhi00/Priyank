//
//  ViewController.h
//  NIPLiOSFramework
//
//  Created by Prerna on 5/13/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WSViewController : UIViewController
{
    
}

@property (strong, nonatomic) NSMutableArray *arrdataSource;
- (IBAction)btnWSGet:(id)sender;
- (IBAction)btnWSPost:(id)sender;
- (IBAction)btnWSJson:(id)sender;
- (IBAction)btnWSParseJSONKeys:(id)sender;


- (void)DisplayEmp:(id)sender;

@property (strong, nonatomic) IBOutlet UITableView *tblData;


@end

