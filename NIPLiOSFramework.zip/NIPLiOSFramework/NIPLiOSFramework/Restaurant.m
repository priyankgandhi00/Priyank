#import "Restaurant.h"

@interface Restaurant ()

// Private interface goes here.

@end

@implementation Restaurant

// Custom logic goes here.

@end
