#import "Contactinfo.h"

@interface Contactinfo ()

// Private interface goes here.

@end

@implementation Contactinfo

// Custom logic goes here.

@end
