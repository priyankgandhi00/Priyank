//
//  Data.m
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "Data.h"
#import "QuestionSets.h"


NSString *const kDataQuestionSets = @"question_sets";


@interface Data ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Data

@synthesize questionSets = _questionSets;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
    NSObject *receivedQuestionSets = [dict objectForKey:kDataQuestionSets];
    NSMutableArray *parsedQuestionSets = [NSMutableArray array];
    if ([receivedQuestionSets isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedQuestionSets) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedQuestionSets addObject:[QuestionSets modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedQuestionSets isKindOfClass:[NSDictionary class]]) {
       [parsedQuestionSets addObject:[QuestionSets modelObjectWithDictionary:(NSDictionary *)receivedQuestionSets]];
    }

    self.questionSets = [NSArray arrayWithArray:parsedQuestionSets];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    NSMutableArray *tempArrayForQuestionSets = [NSMutableArray array];
    for (NSObject *subArrayObject in self.questionSets) {
        if([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForQuestionSets addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForQuestionSets addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForQuestionSets] forKey:kDataQuestionSets];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.questionSets = [aDecoder decodeObjectForKey:kDataQuestionSets];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_questionSets forKey:kDataQuestionSets];
}

- (id)copyWithZone:(NSZone *)zone
{
    Data *copy = [[Data alloc] init];
    
    if (copy) {

        copy.questionSets = [self.questionSets copyWithZone:zone];
    }
    
    return copy;
}


@end
