//
//  Monitors.m
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "Monitors.h"


NSString *const kMonitorsMonitorProfileId = @"monitor_profile_id";
NSString *const kMonitorsMonitorCreated = @"monitor_created";
NSString *const kMonitorsMonitorStatus = @"monitor_status";
NSString *const kMonitorsUserLastName = @"user_last_name";
NSString *const kMonitorsMonitorAddedByUser = @"monitor_added_by_user";
NSString *const kMonitorsMonitorId = @"monitor_id";
NSString *const kMonitorsMonitorUpdated = @"monitor_updated";
NSString *const kMonitorsUserEmail = @"user_email";
NSString *const kMonitorsMonitorPermission = @"monitor_permission";
NSString *const kMonitorsUserFirstName = @"user_first_name";
NSString *const kMonitorsMonitorUserId = @"monitor_user_id";
NSString *const kMonitorsUserImage = @"user_image";


@interface Monitors ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation Monitors

@synthesize monitorProfileId = _monitorProfileId;
@synthesize monitorCreated = _monitorCreated;
@synthesize monitorStatus = _monitorStatus;
@synthesize userLastName = _userLastName;
@synthesize monitorAddedByUser = _monitorAddedByUser;
@synthesize monitorId = _monitorId;
@synthesize monitorUpdated = _monitorUpdated;
@synthesize userEmail = _userEmail;
@synthesize monitorPermission = _monitorPermission;
@synthesize userFirstName = _userFirstName;
@synthesize monitorUserId = _monitorUserId;
@synthesize userImage = _userImage;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.monitorProfileId = [self objectOrNilForKey:kMonitorsMonitorProfileId fromDictionary:dict];
            self.monitorCreated = [self objectOrNilForKey:kMonitorsMonitorCreated fromDictionary:dict];
            self.monitorStatus = [self objectOrNilForKey:kMonitorsMonitorStatus fromDictionary:dict];
            self.userLastName = [self objectOrNilForKey:kMonitorsUserLastName fromDictionary:dict];
            self.monitorAddedByUser = [self objectOrNilForKey:kMonitorsMonitorAddedByUser fromDictionary:dict];
            self.monitorId = [self objectOrNilForKey:kMonitorsMonitorId fromDictionary:dict];
            self.monitorUpdated = [self objectOrNilForKey:kMonitorsMonitorUpdated fromDictionary:dict];
            self.userEmail = [self objectOrNilForKey:kMonitorsUserEmail fromDictionary:dict];
            self.monitorPermission = [self objectOrNilForKey:kMonitorsMonitorPermission fromDictionary:dict];
            self.userFirstName = [self objectOrNilForKey:kMonitorsUserFirstName fromDictionary:dict];
            self.monitorUserId = [self objectOrNilForKey:kMonitorsMonitorUserId fromDictionary:dict];
            self.userImage = [self objectOrNilForKey:kMonitorsUserImage fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.monitorProfileId forKey:kMonitorsMonitorProfileId];
    [mutableDict setValue:self.monitorCreated forKey:kMonitorsMonitorCreated];
    [mutableDict setValue:self.monitorStatus forKey:kMonitorsMonitorStatus];
    [mutableDict setValue:self.userLastName forKey:kMonitorsUserLastName];
    [mutableDict setValue:self.monitorAddedByUser forKey:kMonitorsMonitorAddedByUser];
    [mutableDict setValue:self.monitorId forKey:kMonitorsMonitorId];
    [mutableDict setValue:self.monitorUpdated forKey:kMonitorsMonitorUpdated];
    [mutableDict setValue:self.userEmail forKey:kMonitorsUserEmail];
    [mutableDict setValue:self.monitorPermission forKey:kMonitorsMonitorPermission];
    [mutableDict setValue:self.userFirstName forKey:kMonitorsUserFirstName];
    [mutableDict setValue:self.monitorUserId forKey:kMonitorsMonitorUserId];
    [mutableDict setValue:self.userImage forKey:kMonitorsUserImage];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.monitorProfileId = [aDecoder decodeObjectForKey:kMonitorsMonitorProfileId];
    self.monitorCreated = [aDecoder decodeObjectForKey:kMonitorsMonitorCreated];
    self.monitorStatus = [aDecoder decodeObjectForKey:kMonitorsMonitorStatus];
    self.userLastName = [aDecoder decodeObjectForKey:kMonitorsUserLastName];
    self.monitorAddedByUser = [aDecoder decodeObjectForKey:kMonitorsMonitorAddedByUser];
    self.monitorId = [aDecoder decodeObjectForKey:kMonitorsMonitorId];
    self.monitorUpdated = [aDecoder decodeObjectForKey:kMonitorsMonitorUpdated];
    self.userEmail = [aDecoder decodeObjectForKey:kMonitorsUserEmail];
    self.monitorPermission = [aDecoder decodeObjectForKey:kMonitorsMonitorPermission];
    self.userFirstName = [aDecoder decodeObjectForKey:kMonitorsUserFirstName];
    self.monitorUserId = [aDecoder decodeObjectForKey:kMonitorsMonitorUserId];
    self.userImage = [aDecoder decodeObjectForKey:kMonitorsUserImage];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_monitorProfileId forKey:kMonitorsMonitorProfileId];
    [aCoder encodeObject:_monitorCreated forKey:kMonitorsMonitorCreated];
    [aCoder encodeObject:_monitorStatus forKey:kMonitorsMonitorStatus];
    [aCoder encodeObject:_userLastName forKey:kMonitorsUserLastName];
    [aCoder encodeObject:_monitorAddedByUser forKey:kMonitorsMonitorAddedByUser];
    [aCoder encodeObject:_monitorId forKey:kMonitorsMonitorId];
    [aCoder encodeObject:_monitorUpdated forKey:kMonitorsMonitorUpdated];
    [aCoder encodeObject:_userEmail forKey:kMonitorsUserEmail];
    [aCoder encodeObject:_monitorPermission forKey:kMonitorsMonitorPermission];
    [aCoder encodeObject:_userFirstName forKey:kMonitorsUserFirstName];
    [aCoder encodeObject:_monitorUserId forKey:kMonitorsMonitorUserId];
    [aCoder encodeObject:_userImage forKey:kMonitorsUserImage];
}

- (id)copyWithZone:(NSZone *)zone
{
    Monitors *copy = [[Monitors alloc] init];
    
    if (copy) {

        copy.monitorProfileId = [self.monitorProfileId copyWithZone:zone];
        copy.monitorCreated = [self.monitorCreated copyWithZone:zone];
        copy.monitorStatus = [self.monitorStatus copyWithZone:zone];
        copy.userLastName = [self.userLastName copyWithZone:zone];
        copy.monitorAddedByUser = [self.monitorAddedByUser copyWithZone:zone];
        copy.monitorId = [self.monitorId copyWithZone:zone];
        copy.monitorUpdated = [self.monitorUpdated copyWithZone:zone];
        copy.userEmail = [self.userEmail copyWithZone:zone];
        copy.monitorPermission = [self.monitorPermission copyWithZone:zone];
        copy.userFirstName = [self.userFirstName copyWithZone:zone];
        copy.monitorUserId = [self.monitorUserId copyWithZone:zone];
        copy.userImage = [self.userImage copyWithZone:zone];
    }
    
    return copy;
}


@end
