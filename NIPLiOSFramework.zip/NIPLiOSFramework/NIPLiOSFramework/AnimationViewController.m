//
//  AnimationViewController.m
//  NIPLiOSFramework
//
//  Created by Prerna on 7/1/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import "AnimationViewController.h"
#import "AnimationHelper.h"

@interface AnimationViewController ()

@end

@implementation AnimationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"Tap cell to see animation";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnanimation:(id)sender
{
    [AnimationHelper animationForView:_animateView animationType:animShakeView];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Table Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    cell.imageView.image = [UIImage imageNamed:@"icon"];
    
    cell.textLabel.text = @"No Animation Applied yet";
    
    switch (indexPath.row) {
          
        case 0:
        {
            cell.textLabel.text = @"Zoom In";
        }
        break;
            
        default:
        {
            cell.textLabel.text = @"No Animation Applied yet";
        }
            
       
        break;
    }
    
    
    return cell;
   
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    switch (indexPath.row) {
            
        //Zoom In
        case 0:
        {
            [AnimationHelper animationForView:cell.imageView animationType:animZoomInView];
        }
        break;
            
        default:
        break;
    }
    
}


@end
