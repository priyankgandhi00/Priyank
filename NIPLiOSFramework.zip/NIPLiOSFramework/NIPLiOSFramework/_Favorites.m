// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to Favorites.m instead.

#import "_Favorites.h"

const struct FavoritesAttributes FavoritesAttributes = {
	.favoriteid = @"favoriteid",
	.restaurantname = @"restaurantname",
};

@implementation FavoritesID
@end

@implementation _Favorites

+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"Favorites" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"Favorites";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"Favorites" inManagedObjectContext:moc_];
}

- (FavoritesID*)objectID {
	return (FavoritesID*)[super objectID];
}

+ (NSSet*)keyPathsForValuesAffectingValueForKey:(NSString*)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];

	if ([key isEqualToString:@"favoriteidValue"]) {
		NSSet *affectingKey = [NSSet setWithObject:@"favoriteid"];
		keyPaths = [keyPaths setByAddingObjectsFromSet:affectingKey];
		return keyPaths;
	}

	return keyPaths;
}

@dynamic favoriteid;

- (int16_t)favoriteidValue {
	NSNumber *result = [self favoriteid];
	return [result shortValue];
}

- (void)setFavoriteidValue:(int16_t)value_ {
	[self setFavoriteid:[NSNumber numberWithShort:value_]];
}

- (int16_t)primitiveFavoriteidValue {
	NSNumber *result = [self primitiveFavoriteid];
	return [result shortValue];
}

- (void)setPrimitiveFavoriteidValue:(int16_t)value_ {
	[self setPrimitiveFavoriteid:[NSNumber numberWithShort:value_]];
}

@dynamic restaurantname;

@end

