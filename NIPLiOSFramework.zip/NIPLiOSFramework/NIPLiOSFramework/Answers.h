//
//  Answers.h
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface Answers : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *choice;
@property (nonatomic, strong) NSString *choiceFeedback;
@property (nonatomic, strong) NSString *choiceId;
@property (nonatomic, strong) NSString *imageLink;
@property (nonatomic, strong) NSString *isRight;
@property (nonatomic, strong) NSString *questionId;
@property (nonatomic, strong) NSString *audioLink;
@property (nonatomic, assign) id videoLink;
@property (nonatomic, strong) NSString *text;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
