//
//  CoreDataViewController.m
//  NIPLiOSFramework
//
//  Created by Prerna on 8/3/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import "CoreDataViewController.h"
#import "WebServiceConnector.h"
#import "ReachabilityManager.h"
#import "Constants.h"
#import "FamousFoodWS.h"
#import "CoreDataAdaptor.h"
#import <objc/runtime.h>
#import <CoreData/CoreData.h>
#import "Restaurant.h"

@interface CoreDataViewController ()
{
    NSMutableArray *arrRestaurants;
    NSDictionary *dictRestaurants;
}
@end

@implementation CoreDataViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    arrRestaurants = [NSMutableArray new];
    dictRestaurants = [NSMutableDictionary new];
    if([ReachabilityManager isReachable])
    {
        [[WebServiceConnector alloc]init:URLGetFamousFood
                          withParameters:nil
                              withObject:self
                            withSelector:@selector(DisplayWSResponse:)
                          forServiceType:@"GET"
                          showDisplayMsg:@"No message"];
    }
    else
    {
    }
    
}
- (void)DisplayWSResponse:(id)sender
{
    [SVProgressHUD dismiss];
    if ([sender responseCode] != 100)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:[sender responseError] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
    }
    else
    {
        //NSLog(@"%@", [sender responseArray]);
        //NSLog(@"%@", [sender responseDict]);
        arrRestaurants = (NSMutableArray *)[sender responseArray];
        dictRestaurants = (NSMutableDictionary *)[sender responseDict];
        for (int i =0 ; i<[[sender responseArray] count]; i++)
        {
            FamousFoodWS *food = [[sender responseArray] objectAtIndex:i];
            NSLog(@"Title: %@",food.title);
            NSLog(@"Location: %@",food.location);
            //[CoreDataAdaptor SaveDataInCoreDB:[sender responseDict] forEntity:@"Restaurant"];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnInsert:(id)sender
{
    /*** auto insertion ***/
    //[CoreDataAdaptor SaveDataInCoreDB:dictRestaurants forEntity:@"Restaurant"];
    
    
    /*** manual insertion ***/
    dictRestaurants = [NSMutableDictionary new];
    for(int i=0 ; i<[arrRestaurants count]; i++)
    {
        [dictRestaurants setValue:((FamousFoodWS *)[arrRestaurants objectAtIndex:i]).title forKey:@"title"];
        [dictRestaurants setValue:((FamousFoodWS *)[arrRestaurants objectAtIndex:i]).location forKey:@"location"];
        [dictRestaurants setValue:((FamousFoodWS *)[arrRestaurants objectAtIndex:i]).famousFoodDescription forKey:@"fooddescription"];
        [CoreDataAdaptor SaveDataInCoreDB:dictRestaurants forEntity:@"Restaurant"];
    }
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:@"Message"
                                          message:[NSString stringWithFormat:@"Total records after insert: %ld",[CoreDataAdaptor getRecordCount:@"Restaurant"]]
                                          preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction
                                   actionWithTitle:@"Cancel"
                                   style:UIAlertActionStyleCancel
                                   handler:^(UIAlertAction *action)
                                   {
                                       NSLog(@"Cancel action");
                                   }];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:@"OK"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   NSLog(@"OK action");
                               }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (IBAction)btnDelete:(id)sender
{
    NSString *condition = [NSString stringWithFormat:@"title CONTAINS %@", @"Sai"];
    NSArray *arrResults = [CoreDataAdaptor fetchRestaurantWhere:condition];
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:@"Message"
                                          message:[NSString stringWithFormat:@"Total records found for search criteria : %ld do you wish to delete?",[arrResults count]]
                                          preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:@"Yes"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   [CoreDataAdaptor deleteDataInCoreDB:@"Restaurant" withCondition:condition];
                               }];
    UIAlertAction *cancelAction = [UIAlertAction
                                   actionWithTitle:@"No"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction *action)
                                   {
                                   }];
    [alertController addAction:okAction];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (IBAction)btnSelect1:(id)sender
{
    NSLog(@"%lu",(unsigned long)[[CoreDataAdaptor fetchAllRestaurant] count]);
}

- (IBAction)btnUpdate:(id)sender
{
    [CoreDataAdaptor updateRecords:[NSString stringWithFormat:@"fooddescription contains[c] 'Bhel Puri'"]];
}

- (IBAction)btnDeleteAll:(id)sender
{
    [CoreDataAdaptor deleteAllDataInCoreDB:nil];
}

- (IBAction)btnSelect:(id)sender
{
    //NSLog(@"%lu",(unsigned long)[[CoreDataAdaptor fetchRestaurantWhere:@"landmark = 'Near Iscon Mall'"]count]);
    NSArray *arrRecords = [CoreDataAdaptor fetchRestaurantWhere:@"landmark = 'Near Iscon Mall'"];
    Restaurant *restaurant = [arrRecords objectAtIndex:0];
    NSLog(@"%@",restaurant.title);
}

@end
