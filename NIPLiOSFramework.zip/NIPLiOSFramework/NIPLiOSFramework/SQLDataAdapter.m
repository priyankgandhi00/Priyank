//
//  SQLDataAdapter.m
//  NIPLiOSFramework
//
//  Created by Prerna on 8/17/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import "SQLDataAdapter.h"
#import "SQLDataHelper.h"

#define tblRestaurant @"RestaurantMaster"
SQLDataAdapter *data_adapter;
@implementation SQLDataAdapter

+(SQLDataAdapter*)sharedInstance
{
    @synchronized(self)
    {
        if(data_adapter == nil)
            data_adapter = [[super allocWithZone:NULL] init] ;
    }
    return data_adapter;
}
- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

+ (id)allocWithZone:(NSZone *)zone {
    return [self sharedInstance];
}

- (id)copyWithZone:(NSZone *)zone {
    return self;
}


-(void)copyDatabase
{
    [SQLDataHelper copyDatabaseIfNeeded];
}

-(void)insertRestaurant:(NSDictionary *)dict
{
    [SQLDataHelper ExecuteInsert:tblRestaurant withParameters:dict];
}

-(void)updateRestaurant:(NSDictionary *)dict withCondition:(NSDictionary *)condition
{
    [SQLDataHelper ExecuteUpdate:tblRestaurant withParameters:dict forCondition:condition];
}

-(void)deleteRestaurant
{
    [SQLDataHelper ExecuteDelete:tblRestaurant forCondition:nil];
}

-(void)deleteRestaurant:(NSDictionary *)condition
{
    [SQLDataHelper ExecuteDelete:tblRestaurant forCondition:condition];
}

-(NSMutableArray *)selectAllRestaurant
{
     NSMutableArray *allRestaurant = [SQLDataHelper parseSql:[SQLDataHelper ExecuteReader:[NSString stringWithFormat:@"SELECT * FROM %@",tblRestaurant]]];
    return allRestaurant;
}

-(NSMutableArray *)selectRestaurantByAddress:(NSString *)condition
{
    NSMutableArray *allRestaurant = [SQLDataHelper parseSql:[SQLDataHelper ExecuteReader:[NSString stringWithFormat:@"SELECT * FROM %@ where Address='%@'",tblRestaurant,condition]]];
    return allRestaurant;
}
@end
