//
//  ProfileDetails.m
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "ProfileDetails.h"
#import "Monitors.h"
#import "Tiles.h"


NSString *const kProfileDetailsProfileAge = @"profile_age";
NSString *const kProfileDetailsProfileStatus = @"profile_status";
NSString *const kProfileDetailsUserProfileId = @"user_profile_id";
NSString *const kProfileDetailsProfileId = @"profile_id";
NSString *const kProfileDetailsUserId = @"user_id";
NSString *const kProfileDetailsProfileImage = @"profile_image";
NSString *const kProfileDetailsMonitors = @"monitors";
NSString *const kProfileDetailsProfileLname = @"profile_lname";
NSString *const kProfileDetailsProfileDob = @"profile_dob";
NSString *const kProfileDetailsTiles = @"tiles";
NSString *const kProfileDetailsProfileFname = @"profile_fname";
NSString *const kProfileDetailsUserProfilePermissionStatus = @"user_profile_permission_status";


@interface ProfileDetails ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation ProfileDetails

@synthesize profileAge = _profileAge;
@synthesize profileStatus = _profileStatus;
@synthesize userProfileId = _userProfileId;
@synthesize profileId = _profileId;
@synthesize userId = _userId;
@synthesize profileImage = _profileImage;
@synthesize monitors = _monitors;
@synthesize profileLname = _profileLname;
@synthesize profileDob = _profileDob;
@synthesize tiles = _tiles;
@synthesize profileFname = _profileFname;
@synthesize userProfilePermissionStatus = _userProfilePermissionStatus;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.profileAge = [self objectOrNilForKey:kProfileDetailsProfileAge fromDictionary:dict];
            self.profileStatus = [self objectOrNilForKey:kProfileDetailsProfileStatus fromDictionary:dict];
            self.userProfileId = [self objectOrNilForKey:kProfileDetailsUserProfileId fromDictionary:dict];
            self.profileId = [self objectOrNilForKey:kProfileDetailsProfileId fromDictionary:dict];
            self.userId = [self objectOrNilForKey:kProfileDetailsUserId fromDictionary:dict];
            self.profileImage = [self objectOrNilForKey:kProfileDetailsProfileImage fromDictionary:dict];
    NSObject *receivedMonitors = [dict objectForKey:kProfileDetailsMonitors];
    NSMutableArray *parsedMonitors = [NSMutableArray array];
    if ([receivedMonitors isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedMonitors) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedMonitors addObject:[Monitors modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedMonitors isKindOfClass:[NSDictionary class]]) {
       [parsedMonitors addObject:[Monitors modelObjectWithDictionary:(NSDictionary *)receivedMonitors]];
    }

    self.monitors = [NSArray arrayWithArray:parsedMonitors];
            self.profileLname = [self objectOrNilForKey:kProfileDetailsProfileLname fromDictionary:dict];
            self.profileDob = [self objectOrNilForKey:kProfileDetailsProfileDob fromDictionary:dict];
    NSObject *receivedTiles = [dict objectForKey:kProfileDetailsTiles];
    NSMutableArray *parsedTiles = [NSMutableArray array];
    if ([receivedTiles isKindOfClass:[NSArray class]]) {
        for (NSDictionary *item in (NSArray *)receivedTiles) {
            if ([item isKindOfClass:[NSDictionary class]]) {
                [parsedTiles addObject:[Tiles modelObjectWithDictionary:item]];
            }
       }
    } else if ([receivedTiles isKindOfClass:[NSDictionary class]]) {
       [parsedTiles addObject:[Tiles modelObjectWithDictionary:(NSDictionary *)receivedTiles]];
    }

    self.tiles = [NSArray arrayWithArray:parsedTiles];
            self.profileFname = [self objectOrNilForKey:kProfileDetailsProfileFname fromDictionary:dict];
            self.userProfilePermissionStatus = [self objectOrNilForKey:kProfileDetailsUserProfilePermissionStatus fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.profileAge forKey:kProfileDetailsProfileAge];
    [mutableDict setValue:self.profileStatus forKey:kProfileDetailsProfileStatus];
    [mutableDict setValue:self.userProfileId forKey:kProfileDetailsUserProfileId];
    [mutableDict setValue:self.profileId forKey:kProfileDetailsProfileId];
    [mutableDict setValue:self.userId forKey:kProfileDetailsUserId];
    [mutableDict setValue:self.profileImage forKey:kProfileDetailsProfileImage];
    NSMutableArray *tempArrayForMonitors = [NSMutableArray array];
    for (NSObject *subArrayObject in self.monitors) {
        if([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForMonitors addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForMonitors addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForMonitors] forKey:kProfileDetailsMonitors];
    [mutableDict setValue:self.profileLname forKey:kProfileDetailsProfileLname];
    [mutableDict setValue:self.profileDob forKey:kProfileDetailsProfileDob];
    NSMutableArray *tempArrayForTiles = [NSMutableArray array];
    for (NSObject *subArrayObject in self.tiles) {
        if([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForTiles addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForTiles addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForTiles] forKey:kProfileDetailsTiles];
    [mutableDict setValue:self.profileFname forKey:kProfileDetailsProfileFname];
    [mutableDict setValue:self.userProfilePermissionStatus forKey:kProfileDetailsUserProfilePermissionStatus];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.profileAge = [aDecoder decodeObjectForKey:kProfileDetailsProfileAge];
    self.profileStatus = [aDecoder decodeObjectForKey:kProfileDetailsProfileStatus];
    self.userProfileId = [aDecoder decodeObjectForKey:kProfileDetailsUserProfileId];
    self.profileId = [aDecoder decodeObjectForKey:kProfileDetailsProfileId];
    self.userId = [aDecoder decodeObjectForKey:kProfileDetailsUserId];
    self.profileImage = [aDecoder decodeObjectForKey:kProfileDetailsProfileImage];
    self.monitors = [aDecoder decodeObjectForKey:kProfileDetailsMonitors];
    self.profileLname = [aDecoder decodeObjectForKey:kProfileDetailsProfileLname];
    self.profileDob = [aDecoder decodeObjectForKey:kProfileDetailsProfileDob];
    self.tiles = [aDecoder decodeObjectForKey:kProfileDetailsTiles];
    self.profileFname = [aDecoder decodeObjectForKey:kProfileDetailsProfileFname];
    self.userProfilePermissionStatus = [aDecoder decodeObjectForKey:kProfileDetailsUserProfilePermissionStatus];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_profileAge forKey:kProfileDetailsProfileAge];
    [aCoder encodeObject:_profileStatus forKey:kProfileDetailsProfileStatus];
    [aCoder encodeObject:_userProfileId forKey:kProfileDetailsUserProfileId];
    [aCoder encodeObject:_profileId forKey:kProfileDetailsProfileId];
    [aCoder encodeObject:_userId forKey:kProfileDetailsUserId];
    [aCoder encodeObject:_profileImage forKey:kProfileDetailsProfileImage];
    [aCoder encodeObject:_monitors forKey:kProfileDetailsMonitors];
    [aCoder encodeObject:_profileLname forKey:kProfileDetailsProfileLname];
    [aCoder encodeObject:_profileDob forKey:kProfileDetailsProfileDob];
    [aCoder encodeObject:_tiles forKey:kProfileDetailsTiles];
    [aCoder encodeObject:_profileFname forKey:kProfileDetailsProfileFname];
    [aCoder encodeObject:_userProfilePermissionStatus forKey:kProfileDetailsUserProfilePermissionStatus];
}

- (id)copyWithZone:(NSZone *)zone
{
    ProfileDetails *copy = [[ProfileDetails alloc] init];
    
    if (copy) {

        copy.profileAge = [self.profileAge copyWithZone:zone];
        copy.profileStatus = [self.profileStatus copyWithZone:zone];
        copy.userProfileId = [self.userProfileId copyWithZone:zone];
        copy.profileId = [self.profileId copyWithZone:zone];
        copy.userId = [self.userId copyWithZone:zone];
        copy.profileImage = [self.profileImage copyWithZone:zone];
        copy.monitors = [self.monitors copyWithZone:zone];
        copy.profileLname = [self.profileLname copyWithZone:zone];
        copy.profileDob = [self.profileDob copyWithZone:zone];
        copy.tiles = [self.tiles copyWithZone:zone];
        copy.profileFname = [self.profileFname copyWithZone:zone];
        copy.userProfilePermissionStatus = [self.userProfilePermissionStatus copyWithZone:zone];
    }
    
    return copy;
}


@end
