//
//  SQLDataAdapter.h
//  NIPLiOSFramework
//
//  Created by Prerna on 8/17/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SQLDataAdapter : NSObject
-(void)insertRestaurant:(NSDictionary *)dict;
-(void)updateRestaurant:(NSDictionary *)dict withCondition:(NSDictionary *)condition;
-(void)deleteRestaurant;
-(void)deleteRestaurant:(NSDictionary *)condition;
-(NSMutableArray *)selectAllRestaurant;
-(NSMutableArray *)selectRestaurantByAddress:(NSString *)condition;

-(void)copyDatabase;
+(SQLDataAdapter*)sharedInstance;

@end
