// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to Favorites.h instead.

#import <CoreData/CoreData.h>

extern const struct FavoritesAttributes {
	__unsafe_unretained NSString *favoriteid;
	__unsafe_unretained NSString *restaurantname;
} FavoritesAttributes;

@interface FavoritesID : NSManagedObjectID {}
@end

@interface _Favorites : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
@property (nonatomic, readonly, strong) FavoritesID* objectID;

@property (nonatomic, retain) NSNumber* favoriteid;

@property (atomic) int16_t favoriteidValue;
- (int16_t)favoriteidValue;
- (void)setFavoriteidValue:(int16_t)value_;

//- (BOOL)validateFavoriteid:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* restaurantname;

//- (BOOL)validateRestaurantname:(id*)value_ error:(NSError**)error_;

@end

@interface _Favorites (CoreDataGeneratedPrimitiveAccessors)

- (NSNumber*)primitiveFavoriteid;
- (void)setPrimitiveFavoriteid:(NSNumber*)value;

- (int16_t)primitiveFavoriteidValue;
- (void)setPrimitiveFavoriteidValue:(int16_t)value_;

- (NSString*)primitiveRestaurantname;
- (void)setPrimitiveRestaurantname:(NSString*)value;

@end
