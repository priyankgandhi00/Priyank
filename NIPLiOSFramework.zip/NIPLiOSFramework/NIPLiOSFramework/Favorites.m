#import "Favorites.h"

@interface Favorites ()

// Private interface goes here.

@end

@implementation Favorites

// Custom logic goes here.

@end
