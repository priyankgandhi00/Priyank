//
//  SQLiteViewController.h
//  NIPLiOSFramework
//
//  Created by Prerna on 7/1/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQLiteViewController : UIViewController

- (IBAction)btnCopyDatabase:(id)sender;
- (IBAction)btnInsert:(id)sender;
- (IBAction)btnSelectByArea:(id)sender;
- (IBAction)btnSelectAllRestaurant:(id)sender;
- (IBAction)btnDeleteByID:(id)sender;
- (IBAction)btnUpdate:(id)sender;

@end
