//
//  UploadWSDemoVC.m
//  NIPLiOSFramework
//
//  Created by Prerna on 6/27/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import "UploadWSDemoVC.h"
#import "WebServiceConnector.h"
#import "NSDate+Helper.h"


@implementation UploadWSDemoVC
{
    UIImage *selectedImage;
}

- (IBAction)btnBackClick:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Audio upload
- (IBAction)btnUploadAudio:(id)sender
{
    
}

- (IBAction)btnChoseAudio:(id)sender
{
    MPMediaPickerController *pickerController = [[MPMediaPickerController alloc] initWithMediaTypes:MPMediaTypeMusic];
    pickerController.prompt = @"Select Song";
    pickerController.delegate = self;
    [self presentViewController:pickerController animated:YES completion:nil];
}

- (void)mediaPicker:(MPMediaPickerController *)mediaPicker didPickMediaItems:(MPMediaItemCollection *)mediaItemCollection
{
    MPMediaItem *theChosenSong = [[mediaItemCollection items]objectAtIndex:0];
    NSString *songTitle = [theChosenSong valueForProperty:MPMediaItemPropertyTitle];
    NSURL *assetURL = [theChosenSong valueForProperty:MPMediaItemPropertyAssetURL];
    AVURLAsset  *songAsset  = [AVURLAsset URLAssetWithURL:assetURL options:nil];
    NSLog(@"%@ : %@ ",songTitle, songAsset);
    [mediaPicker dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - Image upload

- (IBAction)btnUploadProfile:(id)sender
{
    UIImage * img = [self scaleAndRotateImage:selectedImage];
    [[WebServiceConnector alloc]init:URLAddProfile
                      withParameters:@{@"profile_fname":@"milan1234@gmail.com",
                                       @"profile_lname":@"password",
                                       @"profile_status":@"0",
                                       @"profile_dob":@"Jan 1,1988",
                                       @"profile_added_by_user":@"10",
                                       @"profile_image_name":[NSString stringWithFormat:@"%@.jpg",CurrentTimeStamp],
                                       @"profile_image":[self encodeImageToBase64String:img]}
                          withObject:self
                        withSelector:@selector(DisplayUploadedImage:)
                      forServiceType:@"JSON"
                      showDisplayMsg:URLAddProfile];
}
-(void)DisplayUploadedImage:(id)sender
{
    
}

- (IBAction)ChoseImagebtnClick:(id)sender
{
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePickerController.delegate = self;
    [self presentViewController:imagePickerController animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    selectedImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    _imgSelectedImage.image = selectedImage;
    [picker dismissViewControllerAnimated:YES completion:nil];
}
@end
