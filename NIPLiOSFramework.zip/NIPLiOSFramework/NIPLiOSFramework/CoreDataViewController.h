//
//  CoreDataViewController.h
//  NIPLiOSFramework
//
//  Created by Prerna on 8/3/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoreDataViewController : UIViewController


- (IBAction)btnInsert:(id)sender;
- (IBAction)btnDelete:(id)sender;

- (IBAction)btnSelect1:(id)sender;
- (IBAction)btnUpdate:(id)sender;

- (IBAction)btnDeleteAll:(id)sender;
- (IBAction)btnSelect:(id)sender;


@end
