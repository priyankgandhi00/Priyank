// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to Contactinfo.m instead.

#import "_Contactinfo.h"

const struct ContactinfoAttributes ContactinfoAttributes = {
	.contactid = @"contactid",
	.contactname = @"contactname",
	.contactnumber = @"contactnumber",
	.restaurantname = @"restaurantname",
};

@implementation ContactinfoID
@end

@implementation _Contactinfo

+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"Contactinfo" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"Contactinfo";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"Contactinfo" inManagedObjectContext:moc_];
}

- (ContactinfoID*)objectID {
	return (ContactinfoID*)[super objectID];
}

+ (NSSet*)keyPathsForValuesAffectingValueForKey:(NSString*)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];

	if ([key isEqualToString:@"contactidValue"]) {
		NSSet *affectingKey = [NSSet setWithObject:@"contactid"];
		keyPaths = [keyPaths setByAddingObjectsFromSet:affectingKey];
		return keyPaths;
	}
	if ([key isEqualToString:@"contactnumberValue"]) {
		NSSet *affectingKey = [NSSet setWithObject:@"contactnumber"];
		keyPaths = [keyPaths setByAddingObjectsFromSet:affectingKey];
		return keyPaths;
	}

	return keyPaths;
}

@dynamic contactid;

- (int16_t)contactidValue {
	NSNumber *result = [self contactid];
	return [result shortValue];
}

- (void)setContactidValue:(int16_t)value_ {
	[self setContactid:[NSNumber numberWithShort:value_]];
}

- (int16_t)primitiveContactidValue {
	NSNumber *result = [self primitiveContactid];
	return [result shortValue];
}

- (void)setPrimitiveContactidValue:(int16_t)value_ {
	[self setPrimitiveContactid:[NSNumber numberWithShort:value_]];
}

@dynamic contactname;

@dynamic contactnumber;

- (int32_t)contactnumberValue {
	NSNumber *result = [self contactnumber];
	return [result intValue];
}

- (void)setContactnumberValue:(int32_t)value_ {
	[self setContactnumber:[NSNumber numberWithInt:value_]];
}

- (int32_t)primitiveContactnumberValue {
	NSNumber *result = [self primitiveContactnumber];
	return [result intValue];
}

- (void)setPrimitiveContactnumberValue:(int32_t)value_ {
	[self setPrimitiveContactnumber:[NSNumber numberWithInt:value_]];
}

@dynamic restaurantname;

@end

