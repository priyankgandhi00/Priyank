// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to Restaurant.h instead.

#import <CoreData/CoreData.h>

extern const struct RestaurantAttributes
{
	__unsafe_unretained NSString *areaid;
	__unsafe_unretained NSString *call;
	__unsafe_unretained NSString *fooddescription;
	__unsafe_unretained NSString *foodid;
	__unsafe_unretained NSString *landmark;
	__unsafe_unretained NSString *location;
	__unsafe_unretained NSString *numberofreviews;
	__unsafe_unretained NSString *partyorder;
	__unsafe_unretained NSString *ratings;
	__unsafe_unretained NSString *sitting;
	__unsafe_unretained NSString *timing;
	__unsafe_unretained NSString *title;
} RestaurantAttributes;

extern const struct RestaurantRelationships
{
	__unsafe_unretained NSString *imageinfo;
} RestaurantRelationships;

@class Images;

@interface RestaurantID : NSManagedObjectID {}
@end

@interface _Restaurant : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
@property (nonatomic, readonly, strong) RestaurantID* objectID;

@property (nonatomic, retain) NSString* areaid;

//- (BOOL)validateAreaid:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSNumber* call;

@property (atomic) int32_t callValue;
- (int32_t)callValue;
- (void)setCallValue:(int32_t)value_;

//- (BOOL)validateCall:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* fooddescription;

//- (BOOL)validateFooddescription:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSNumber* foodid;

@property (atomic) int16_t foodidValue;
- (int16_t)foodidValue;
- (void)setFoodidValue:(int16_t)value_;

//- (BOOL)validateFoodid:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* landmark;

//- (BOOL)validateLandmark:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* location;

//- (BOOL)validateLocation:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* numberofreviews;

//- (BOOL)validateNumberofreviews:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* partyorder;

//- (BOOL)validatePartyorder:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* ratings;

//- (BOOL)validateRatings:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* sitting;

//- (BOOL)validateSitting:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* timing;

//- (BOOL)validateTiming:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* title;

//- (BOOL)validateTitle:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) Images *imageinfo;

//- (BOOL)validateImageinfo:(id*)value_ error:(NSError**)error_;

@end

@interface _Restaurant (CoreDataGeneratedPrimitiveAccessors)

- (NSString*)primitiveAreaid;
- (void)setPrimitiveAreaid:(NSString*)value;

- (NSNumber*)primitiveCall;
- (void)setPrimitiveCall:(NSNumber*)value;

- (int32_t)primitiveCallValue;
- (void)setPrimitiveCallValue:(int32_t)value_;

- (NSString*)primitiveFooddescription;
- (void)setPrimitiveFooddescription:(NSString*)value;

- (NSNumber*)primitiveFoodid;
- (void)setPrimitiveFoodid:(NSNumber*)value;

- (int16_t)primitiveFoodidValue;
- (void)setPrimitiveFoodidValue:(int16_t)value_;

- (NSString*)primitiveLandmark;
- (void)setPrimitiveLandmark:(NSString*)value;

- (NSString*)primitiveLocation;
- (void)setPrimitiveLocation:(NSString*)value;

- (NSString*)primitiveNumberofreviews;
- (void)setPrimitiveNumberofreviews:(NSString*)value;

- (NSString*)primitivePartyorder;
- (void)setPrimitivePartyorder:(NSString*)value;

- (NSString*)primitiveRatings;
- (void)setPrimitiveRatings:(NSString*)value;

- (NSString*)primitiveSitting;
- (void)setPrimitiveSitting:(NSString*)value;

- (NSString*)primitiveTiming;
- (void)setPrimitiveTiming:(NSString*)value;

- (NSString*)primitiveTitle;
- (void)setPrimitiveTitle:(NSString*)value;

- (Images*)primitiveImageinfo;
- (void)setPrimitiveImageinfo:(Images*)value;

@end
