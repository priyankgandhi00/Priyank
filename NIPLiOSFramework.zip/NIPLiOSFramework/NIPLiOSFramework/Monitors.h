//
//  Monitors.h
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface Monitors : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *monitorProfileId;
@property (nonatomic, strong) NSString *monitorCreated;
@property (nonatomic, strong) NSString *monitorStatus;
@property (nonatomic, strong) NSString *userLastName;
@property (nonatomic, strong) NSString *monitorAddedByUser;
@property (nonatomic, strong) NSString *monitorId;
@property (nonatomic, strong) NSString *monitorUpdated;
@property (nonatomic, strong) NSString *userEmail;
@property (nonatomic, strong) NSString *monitorPermission;
@property (nonatomic, strong) NSString *userFirstName;
@property (nonatomic, strong) NSString *monitorUserId;
@property (nonatomic, strong) NSString *userImage;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
