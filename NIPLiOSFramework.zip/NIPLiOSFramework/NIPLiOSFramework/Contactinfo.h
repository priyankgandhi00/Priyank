#import "_Contactinfo.h"

@interface Contactinfo : _Contactinfo {}
// Custom logic goes here.
@end
