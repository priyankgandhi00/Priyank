// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to Restaurant.m instead.

#import "_Restaurant.h"

const struct RestaurantAttributes RestaurantAttributes = {
	.areaid = @"areaid",
	.call = @"call",
	.fooddescription = @"fooddescription",
	.foodid = @"foodid",
	.landmark = @"landmark",
	.location = @"location",
	.numberofreviews = @"numberofreviews",
	.partyorder = @"partyorder",
	.ratings = @"ratings",
	.sitting = @"sitting",
	.timing = @"timing",
	.title = @"title",
};

const struct RestaurantRelationships RestaurantRelationships = {
	.imageinfo = @"imageinfo",
};

@implementation RestaurantID
@end

@implementation _Restaurant

+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"Restaurant" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"Restaurant";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"Restaurant" inManagedObjectContext:moc_];
}

- (RestaurantID*)objectID {
	return (RestaurantID*)[super objectID];
}

+ (NSSet*)keyPathsForValuesAffectingValueForKey:(NSString*)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];

	if ([key isEqualToString:@"callValue"]) {
		NSSet *affectingKey = [NSSet setWithObject:@"call"];
		keyPaths = [keyPaths setByAddingObjectsFromSet:affectingKey];
		return keyPaths;
	}
	if ([key isEqualToString:@"foodidValue"]) {
		NSSet *affectingKey = [NSSet setWithObject:@"foodid"];
		keyPaths = [keyPaths setByAddingObjectsFromSet:affectingKey];
		return keyPaths;
	}

	return keyPaths;
}

@dynamic areaid;

@dynamic call;

- (int32_t)callValue {
	NSNumber *result = [self call];
	return [result intValue];
}

- (void)setCallValue:(int32_t)value_ {
	[self setCall:[NSNumber numberWithInt:value_]];
}

- (int32_t)primitiveCallValue {
	NSNumber *result = [self primitiveCall];
	return [result intValue];
}

- (void)setPrimitiveCallValue:(int32_t)value_ {
	[self setPrimitiveCall:[NSNumber numberWithInt:value_]];
}

@dynamic fooddescription;

@dynamic foodid;

- (int16_t)foodidValue {
	NSNumber *result = [self foodid];
	return [result shortValue];
}

- (void)setFoodidValue:(int16_t)value_ {
	[self setFoodid:[NSNumber numberWithShort:value_]];
}

- (int16_t)primitiveFoodidValue {
	NSNumber *result = [self primitiveFoodid];
	return [result shortValue];
}

- (void)setPrimitiveFoodidValue:(int16_t)value_ {
	[self setPrimitiveFoodid:[NSNumber numberWithShort:value_]];
}

@dynamic landmark;

@dynamic location;

@dynamic numberofreviews;

@dynamic partyorder;

@dynamic ratings;

@dynamic sitting;

@dynamic timing;

@dynamic title;

@dynamic imageinfo;

@end

