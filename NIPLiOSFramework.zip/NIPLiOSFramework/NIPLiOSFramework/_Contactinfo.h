// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to Contactinfo.h instead.

#import <CoreData/CoreData.h>

extern const struct ContactinfoAttributes
{
	__unsafe_unretained NSString *contactid;
	__unsafe_unretained NSString *contactname;
	__unsafe_unretained NSString *contactnumber;
	__unsafe_unretained NSString *restaurantname;
} ContactinfoAttributes;

@interface ContactinfoID : NSManagedObjectID {}
@end

@interface _Contactinfo : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
@property (nonatomic, readonly, strong) ContactinfoID* objectID;

@property (nonatomic, retain) NSNumber* contactid;

@property (atomic) int16_t contactidValue;
- (int16_t)contactidValue;
- (void)setContactidValue:(int16_t)value_;

//- (BOOL)validateContactid:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* contactname;

//- (BOOL)validateContactname:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSNumber* contactnumber;

@property (atomic) int32_t contactnumberValue;
- (int32_t)contactnumberValue;
- (void)setContactnumberValue:(int32_t)value_;

//- (BOOL)validateContactnumber:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* restaurantname;

//- (BOOL)validateRestaurantname:(id*)value_ error:(NSError**)error_;

@end

@interface _Contactinfo (CoreDataGeneratedPrimitiveAccessors)

- (NSNumber*)primitiveContactid;
- (void)setPrimitiveContactid:(NSNumber*)value;

- (int16_t)primitiveContactidValue;
- (void)setPrimitiveContactidValue:(int16_t)value_;

- (NSString*)primitiveContactname;
- (void)setPrimitiveContactname:(NSString*)value;

- (NSNumber*)primitiveContactnumber;
- (void)setPrimitiveContactnumber:(NSNumber*)value;

- (int32_t)primitiveContactnumberValue;
- (void)setPrimitiveContactnumberValue:(int32_t)value_;

- (NSString*)primitiveRestaurantname;
- (void)setPrimitiveRestaurantname:(NSString*)value;

@end
