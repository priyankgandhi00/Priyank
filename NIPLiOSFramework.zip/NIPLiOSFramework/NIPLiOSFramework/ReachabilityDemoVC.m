//
//  ViewController.m
//  Reachability
//
//  Created by Prerna on 10/12/16.
//  Copyright © 2016 NarolaInfotech. All rights reserved.
//

#import "ReachabilityDemoVC.h"
#import "Reachability.h"
#import "ReachabilityManager.h"

@interface ReachabilityDemoVC ()

@end

@implementation ReachabilityDemoVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityDidChange:) name:kReachabilityChangedNotification object:nil];
    NSLog(@"===>value: %d",[ReachabilityManager isReachable]);
}


- (void)reachabilityDidChange:(NSNotification *)notification
{
    Reachability *reachability = (Reachability *)[notification object];
    
    if ([reachability isReachable]) {
        NSLog(@"===> Reachable");
    } else {
        NSLog(@"===> Unreachable");
    }
}

@end
