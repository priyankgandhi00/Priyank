//
//  QuestionSets.h
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface QuestionSets : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *questionFormat;
@property (nonatomic, strong) NSString *questionSetsId;
@property (nonatomic, strong) NSString *questionUpdateDatetime;
@property (nonatomic, strong) NSString *questionPublicPrivateFlag;
@property (nonatomic, strong) NSString *questionAudioLink;
@property (nonatomic, strong) NSString *difficultyId;
@property (nonatomic, strong) NSString *questionTitle;
@property (nonatomic, strong) NSString *questionCreatorUserId;
@property (nonatomic, strong) NSString *answerChoiceTypeId;
@property (nonatomic, strong) NSArray *answers;
@property (nonatomic, strong) NSString *tagImage;
@property (nonatomic, strong) NSString *questionId;
@property (nonatomic, strong) NSString *questionAssetsLink;
@property (nonatomic, strong) NSString *questionAssetName;
@property (nonatomic, strong) NSString *isActive;
@property (nonatomic, strong) NSString *tagId;
@property (nonatomic, strong) NSString *questionCreationDatetime;
@property (nonatomic, strong) NSString *questionCorrectAnswerType;
@property (nonatomic, strong) NSString *tagDesc;
@property (nonatomic, strong) NSString *questionTitleHint;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
