// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to Images.h instead.

#import <CoreData/CoreData.h>

extern const struct ImagesAttributes {
	__unsafe_unretained NSString *imageid;
	__unsafe_unretained NSString *imagename;
} ImagesAttributes;

extern const struct ImagesRelationships {
	__unsafe_unretained NSString *restrodetail;
} ImagesRelationships;

@class Restaurant;

@interface ImagesID : NSManagedObjectID {}
@end

@interface _Images : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
@property (nonatomic, readonly, strong) ImagesID* objectID;

@property (nonatomic, retain) NSNumber* imageid;

@property (atomic) int16_t imageidValue;
- (int16_t)imageidValue;
- (void)setImageidValue:(int16_t)value_;

//- (BOOL)validateImageid:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) NSString* imagename;

//- (BOOL)validateImagename:(id*)value_ error:(NSError**)error_;

@property (nonatomic, retain) Restaurant *restrodetail;

//- (BOOL)validateRestrodetail:(id*)value_ error:(NSError**)error_;

@end

@interface _Images (CoreDataGeneratedPrimitiveAccessors)

- (NSNumber*)primitiveImageid;
- (void)setPrimitiveImageid:(NSNumber*)value;

- (int16_t)primitiveImageidValue;
- (void)setPrimitiveImageidValue:(int16_t)value_;

- (NSString*)primitiveImagename;
- (void)setPrimitiveImagename:(NSString*)value;

- (Restaurant*)primitiveRestrodetail;
- (void)setPrimitiveRestrodetail:(Restaurant*)value;

@end
