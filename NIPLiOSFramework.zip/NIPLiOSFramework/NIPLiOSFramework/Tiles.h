//
//  Tiles.h
//
//  Created by Prerna  on 6/25/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface Tiles : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *tileId;
@property (nonatomic, strong) NSString *tagImage;
@property (nonatomic, strong) NSString *configId;
@property (nonatomic, strong) NSString *tagId;
@property (nonatomic, strong) NSString *position;
@property (nonatomic, strong) NSString *tagDesc;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
