//
//  AnimationHelper.h
//  NIPLiOSFramework
//
//  Created by Prerna on 5/27/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef enum
{
    animShakeView,
    animBlinkView,
    animZoomInView
} animationType;

@interface AnimationHelper : NSObject 

+ (UIView *) animationForView: (UIView *)animateView animationType:(animationType)animationType;
- (UIView *) shakeViewAnimation:(UIView *)view;

@end
