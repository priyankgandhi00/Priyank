//
//  AnimationHelper.m
//  NIPLiOSFramework
//
//  Created by Prerna on 5/27/15.
//  Copyright (c) 2015 Prerna. All rights reserved.
//

#import "AnimationHelper.h"

@implementation AnimationHelper

+ (UIView *) animationForView: (UIView *)animateView animationType:(animationType)animationType
{
    switch (animationType)
    {
        case animShakeView:
        {
            if([animateView isKindOfClass:[UIButton class]])
            {
                UIButton *btn = (UIButton *)animateView;
                animateView = [[AnimationHelper alloc] shakeViewAnimation:btn];
                //animateView = [[AnimationHelper alloc] blinkViewAnimation:btn];
            }
        }
            break;
        case animBlinkView:
        {
            
        }
            break;
            
        case animZoomInView:
        {
            animateView = [[AnimationHelper alloc] zoomIn:animateView andAnimationDuration:1.0 andWait:NO];
        }
            break;
            
        default:
            break;
    }
    return animateView;
}
-(UIView *) blinkViewAnimation:(UIView *)view
{
    view.transform = CGAffineTransformMakeScale(0.0, 0.0);
    
    [UIView animateWithDuration:0.8
                          delay:0.0
         usingSpringWithDamping:.8
          initialSpringVelocity:.2
                        options:UIViewAnimationOptionAllowUserInteraction
                     animations:^{
                         view.transform = CGAffineTransformMakeScale(1.0,1.0);
                     }
                     completion:^(BOOL finished) {
                     }];
    return view;
}

- (UIView *) shakeViewAnimation:(UIView *)view
{
    [UIView animateKeyframesWithDuration:0.5 delay:0.0 options:0 animations:^{
        [UIView setAnimationCurve:UIViewAnimationCurveLinear];
        
        NSInteger repeatCount = 8;
        NSTimeInterval duration = 1.0 / (NSTimeInterval)repeatCount;
        
        for (NSInteger i = 0; i < repeatCount; i++)
        {
            [UIView addKeyframeWithRelativeStartTime:i * duration relativeDuration:duration animations:^{
                CGFloat dx = 5.0;
                if (i == repeatCount - 1) {
                    view.transform = CGAffineTransformIdentity;
                } else if (i % 2) {
                    view.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, -dx, 0.0);
                } else {
                    view.transform = CGAffineTransformTranslate(CGAffineTransformIdentity, +dx, 0.0);
                }
            }];
        }
    } completion:^(BOOL finished)
     {
         dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
                        {
                        });
     }];
    return view;
}

- (UIView *)zoomIn: (UIView *)view andAnimationDuration: (float) duration andWait:(BOOL) wait
{
    __block BOOL done = wait; //wait =  YES wait to finish animation
    view.transform = CGAffineTransformMakeScale(0, 0);
    [UIView animateWithDuration:duration animations:^{
        view.transform = CGAffineTransformIdentity;
        //view.transform = CGAffineTransformMakeScale(0, 0);
        //view.transform = CGAffineTransformIdentity;
        
    } completion:^(BOOL finished) {
        done = NO;
    }];
    // wait for animation to finish
    while (done == YES)
        [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
    
    return view;

}

@end
